// A wallet whose keys live in another app. The host connects it (for example
// over WizardConnect hdwalletv1) and passes the shared branch xpubs and a
// signer. This session watches those addresses through Electrum, prepares
// BCH payments, asks the signer to sign them without broadcasting, verifies
// the signed bytes against what it built, and broadcasts only after the host
// has persisted the pending record. No private key ever enters this session.
import {
  binToHex, binsAreEqual, createVirtualMachineBch2025, createVirtualMachineBch2026, decodeHdPublicKey,
  decodeTransaction, deriveHdPathRelative, encodeTransaction, getDustThreshold, hashTransaction, hexToBin,
  lockingBytecodeToCashAddress, publicKeyToP2pkhLockingBytecode, sha256,
} from '@bitauth/libauth';
import { Satoshis, TransactionHash } from '@xo-cash/primitives';
import { z } from 'zod';
import { ElectrumClient } from './electrum.js';
import { BroadcastUncertainError, WalletOperationError } from './errors.js';
import { NETWORKS, networkName } from './networks.js';
import { formatBch, parseBch, validateRecipient } from './core.js';

export const CONNECTED_PATH = 'connected';
const BRANCHES = Object.freeze({ receive: 0, change: 1 });
const REVIEW_MS = 120000;
const FINAL_SEQUENCE = 0xffffffff;
const P2PKH_DUST = 546n;
const GAP_LIMIT = 20;
const MAX_INDEX = 1000;
const MAX_INPUTS = 100;

const hex = z.string().regex(/^(?:[a-fA-F0-9]{2})+$/);
const txid = z.string().regex(/^[a-fA-F0-9]{64}$/).transform(value => value.toLowerCase());
const unspentList = z.array(z.object({
  tx_hash: z.string().length(64).regex(/^[a-fA-F0-9]+$/),
  tx_pos: z.number().int().min(0).max(0xffffffff),
  value: z.number().int().safe().nonnegative().max(2100000000000000),
  height: z.number().int(), token_data: z.unknown().optional(),
})).max(200);
const historyList = z.array(z.object({ tx_hash: txid, height: z.number().int() }).passthrough()).max(20000);
const outpoint = z.object({ txid, index: z.number().int().min(0).max(0xffffffff) }).strict();
const pendingRecord = z.object({
  version: z.literal(1), network: networkName, kind: z.literal('payment'), txid,
  path: z.literal(CONNECTED_PATH), address: z.string().max(120),
  category: z.null(), inputs: z.array(outpoint).min(1).max(MAX_INPUTS),
  createdAt: z.number().int().nonnegative(), publication: z.null(),
}).strict();
const pathXpub = z.object({ name: z.string().min(1).max(40), xpub: z.string().min(100).max(200) }).passthrough();
const options = z.object({
  network: networkName.default('chipnet'),
  paths: z.array(pathXpub).min(1).max(16),
  signer: z.custom(value => typeof value === 'function', 'A signer function is required.'),
  walletName: z.string().trim().max(80).optional(),
  gapLimit: z.number().int().min(1).max(100).default(GAP_LIMIT),
}).passthrough();

const outpointId = item => `${item.txid}:${item.index}`;

let verifiers;
function verifySigned(transaction, sourceOutputs) {
  if (!verifiers) verifiers = [['BCH 2025', createVirtualMachineBch2025(true)], ['BCH 2026', createVirtualMachineBch2026(true)]];
  for (const [name, vm] of verifiers) {
    const result = vm.verify({ transaction, sourceOutputs });
    if (result !== true) throw new WalletOperationError('signature-invalid', `The connected wallet returned a transaction that does not validate (${name}): ${result}`);
  }
}

/**
 * Watch and spend a wallet whose keys stay in another app.
 *
 * `paths` are hdwalletv1 branch xpubs (`receive` is required, `change` is
 * optional). `signer({ transaction, sourceOutputs, inputPaths, broadcast,
 * userPrompt })` must return the fully signed transaction as hex and must not
 * broadcast it; this session broadcasts after the host persists the record.
 */
export function createConnectedSession(input) {
  const parsed = options.parse(input);
  const nodes = {};
  for (const { name, xpub } of parsed.paths) {
    if (!(name in BRANCHES)) continue;
    const decoded = decodeHdPublicKey(xpub);
    if (typeof decoded === 'string') throw new WalletOperationError('invalid-xpub', `The connected wallet shared an invalid ${name} key: ${decoded}`);
    const expected = parsed.network === 'mainnet' ? 'mainnet' : 'testnet';
    if (decoded.network !== expected) throw new WalletOperationError('wrong-network', `The connected wallet is on ${decoded.network === 'mainnet' ? 'Mainnet' : 'a test network'}; switch Gam’eya to the same network.`);
    nodes[name] = decoded.node;
  }
  if (!nodes.receive) throw new WalletOperationError('receive-required', 'The connected wallet did not share its receive addresses.');
  const client = parsed.client || new ElectrumClient(parsed.endpoint || NETWORKS[parsed.network].endpoint);
  return new ConnectedSession(parsed.network, nodes, parsed.signer, client, parsed.walletName ?? null, parsed.gapLimit);
}

class ConnectedSession {
  #nodes; #signer; #client; #gap;
  #entries = new Map();
  #used = { receive: new Set(), change: new Set() };
  #verified; #closed = false; #busy = false;
  #draft; #pending; #generation = 0; #sequence = 0;

  constructor(network, nodes, signer, client, walletName, gap) {
    this.#nodes = nodes; this.#signer = signer; this.#client = client; this.#gap = gap;
    this.network = network;
    this.path = CONNECTED_PATH;
    this.kind = 'connected';
    this.walletName = walletName;
    const first = this.#entry('receive', 0);
    this.address = first.address;
    this.tokenAddress = first.tokenAddress;
    this.receiveAddress = first.address;
    Object.defineProperties(this, Object.fromEntries(['network', 'path', 'kind', 'address', 'tokenAddress'].map(name => [name, { writable: false, configurable: false }])));
  }

  #assertOpen() { if (this.#closed) throw new Error('Wallet session is closed.'); }

  #entry(name, index) {
    const key = `${name}/${index}`;
    let entry = this.#entries.get(key);
    if (entry) return entry;
    const node = deriveHdPathRelative(this.#nodes[name], String(index));
    const locking = publicKeyToP2pkhLockingBytecode({ publicKey: node.publicKey });
    const prefix = NETWORKS[this.network].prefix;
    const address = lockingBytecodeToCashAddress({ bytecode: locking, prefix });
    const tokenAddress = lockingBytecodeToCashAddress({ bytecode: locking, prefix, tokenSupport: true });
    if (typeof address === 'string' || typeof tokenAddress === 'string') throw new Error('Could not derive a connected address.');
    entry = Object.freeze({ name, index, locking, scriptHash: binToHex(sha256.hash(locking).reverse()), address: address.address, tokenAddress: tokenAddress.address });
    this.#entries.set(key, entry);
    return entry;
  }

  async #verifyNetwork() {
    this.#assertOpen();
    if (!this.#verified) this.#verified = (async () => {
      await this.#client.request('server.version', ['react-native-xo', '1.4']);
      const config = NETWORKS[this.network];
      const header = hex.length(160).parse(await this.#client.request('blockchain.block.header', [config.checkpointHeight]));
      if (hashTransaction(hexToBin(header)) !== config.checkpointHash) throw new Error('Electrum server is on the wrong network.');
    })().catch(error => { this.#verified = undefined; throw error; });
    await this.#verified;
    this.#assertOpen();
  }

  async #history(entry) {
    return historyList.parse(await this.#client.request('blockchain.scripthash.get_history', [entry.scriptHash]));
  }

  /** Gap-limit discovery on each shared branch; receive/0 is always watched. */
  async #scan() {
    await this.#verifyNetwork();
    const watched = [this.#entry('receive', 0)];
    for (const name of Object.keys(this.#nodes)) {
      let index = 0, gap = 0;
      while (gap < this.#gap && index < MAX_INDEX) {
        const batch = [];
        for (let i = 0; i < this.#gap - gap && index + i < MAX_INDEX; i++) batch.push(this.#entry(name, index + i));
        const histories = await Promise.all(batch.map(entry => this.#history(entry)));
        for (const [i, history] of histories.entries()) {
          if (history.length) { this.#used[name].add(batch[i].index); gap = 0; if (batch[i].index !== 0 || name !== 'receive') watched.push(batch[i]); }
          else gap++;
        }
        index += batch.length;
      }
    }
    this.#assertOpen();
    this.receiveAddress = this.#next('receive').address;
    return watched;
  }

  #next(name) {
    let index = 0;
    while (this.#used[name].has(index)) index++;
    return this.#entry(name, index);
  }

  async #fetchTransaction(hash) {
    const raw = hex.parse(await this.#client.request('blockchain.transaction.get', [hash, false]));
    const bytes = hexToBin(raw);
    if (hashTransaction(bytes) !== hash) throw new Error('Electrum returned a transaction with the wrong hash.');
    const transaction = decodeTransaction(bytes);
    if (typeof transaction === 'string') throw new Error('Electrum returned an invalid transaction.');
    return transaction;
  }

  /** BCH-only, non-coinbase outputs, each re-derived from its hash-verified source transaction. */
  async #utxos() {
    const watched = await this.#scan();
    const lists = await Promise.all(watched.map(entry => this.#client.request('blockchain.scripthash.listunspent', [entry.scriptHash, 'include_tokens']).then(list => unspentList.parse(list))));
    const seen = new Set();
    const verified = [];
    for (const [i, list] of lists.entries()) {
      const entry = watched[i];
      for (const item of list) {
        const id = `${item.tx_hash.toLowerCase()}:${item.tx_pos}`;
        if (seen.has(id)) throw new Error('Electrum returned duplicate outputs.');
        seen.add(id);
        if (item.token_data || item.height < 0) continue;
        const hash = item.tx_hash.toLowerCase();
        const transaction = await this.#fetchTransaction(hash);
        const output = transaction.outputs[item.tx_pos];
        if (!output || output.valueSatoshis !== BigInt(item.value) || !binsAreEqual(output.lockingBytecode, entry.locking)) throw new Error('Electrum output does not match the connected wallet or amount.');
        const coinbase = transaction.inputs.some(input => input.outpointTransactionHash.every(byte => byte === 0));
        if (output.token || coinbase) continue;
        verified.push({ txid: new TransactionHash(hash).toHex(), index: item.tx_pos, valueSatoshis: new Satoshis(item.value).toBigInt(), height: item.height, output, entry });
      }
    }
    this.#assertOpen();
    return verified.sort((a, b) => a.txid.localeCompare(b.txid) || a.index - b.index);
  }

  async refresh() {
    const utxos = await this.#utxos();
    if (this.#pending && await this.#inputsAllSpent(this.#pending)) this.#pending = undefined;
    const total = utxos.reduce((sum, utxo) => sum + utxo.valueSatoshis, 0n);
    return Object.freeze({ address: this.address, receiveAddress: this.receiveAddress, network: this.network, balanceSatoshis: total.toString(), balanceBch: formatBch(total), outputCount: utxos.length });
  }

  async #prepare(build) {
    this.#assertOpen();
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    if (this.#pending) throw new WalletOperationError('pending', 'Resolve the pending transaction before preparing another one.');
    this.#busy = true;
    this.#draft = undefined;
    const generation = ++this.#generation;
    try {
      const draft = await build(() => {
        this.#assertOpen();
        if (generation !== this.#generation) throw new WalletOperationError('cancelled', 'The review was cancelled.');
      });
      this.#assertOpen();
      if (generation !== this.#generation) throw new WalletOperationError('cancelled', 'The review was cancelled.');
      this.#draft = draft;
      return draft.review;
    } finally { this.#busy = false; }
  }

  #pendingRecord(hash, inputs, createdAt = Date.now()) {
    return Object.freeze({ version: 1, network: this.network, path: this.path, address: this.address, kind: 'payment', txid: hash, category: null, inputs: Object.freeze(inputs.map(item => Object.freeze({ txid: item.txid, index: item.index }))), createdAt, publication: null });
  }

  /**
   * Build the payment, then ask the connected wallet to sign it. The returned
   * review describes the exact signed bytes; nothing is broadcast here.
   */
  prepareSend({ address, amountBch }) {
    return this.#prepare(async active => {
      const recipient = validateRecipient(address, this.network);
      const amount = parseBch(amountBch);
      if (amount < P2PKH_DUST) throw new Error('Minimum payment is 0.00000546 BCH (546 satoshis).');
      if (amount < getDustThreshold({ lockingBytecode: recipient.bytecode, valueSatoshis: amount })) throw new WalletOperationError('dust', 'This recipient requires a higher amount to avoid a dust output.');
      const available = await this.#utxos();
      const selected = [];
      const totals = { value: 0n, fee: 0n };
      for (const utxo of available) {
        selected.push(utxo); totals.value += utxo.valueSatoshis;
        // 1 sat/byte with 148-byte inputs: room for ECDSA or Schnorr signatures.
        totals.fee = BigInt(10 + selected.length * 148 + 8 + 1 + recipient.bytecode.length + 34);
        if (totals.value >= amount + totals.fee) break;
        if (selected.length >= MAX_INPUTS) throw new Error('Consolidate outputs before sending: maximum 100 inputs.');
      }
      if (totals.value < amount + totals.fee) throw new Error('Insufficient BCH for this amount and its network fee.');
      const changeValue = totals.value - amount - totals.fee;
      const change = this.#nodes.change ? this.#next('change') : this.#entry('receive', 0);
      const outputs = [{ lockingBytecode: recipient.bytecode, valueSatoshis: amount }, ...(changeValue >= P2PKH_DUST ? [{ lockingBytecode: change.locking, valueSatoshis: changeValue }] : [])];
      const unsigned = { version: 2, locktime: 0, inputs: selected.map(utxo => ({ outpointTransactionHash: hexToBin(utxo.txid), outpointIndex: utxo.index, sequenceNumber: FINAL_SEQUENCE, unlockingBytecode: Uint8Array.of() })), outputs };
      const unsignedBytes = encodeTransaction(unsigned);
      const sourceOutputs = selected.map((utxo, i) => ({ ...unsigned.inputs[i], lockingBytecode: utxo.output.lockingBytecode, valueSatoshis: utxo.output.valueSatoshis }));
      const response = await this.#signer(Object.freeze({
        transaction: binToHex(unsignedBytes),
        sourceOutputs,
        inputPaths: selected.map((utxo, i) => [i, utxo.entry.name, utxo.entry.index]),
        broadcast: false,
        userPrompt: `Send ${formatBch(amount)} BCH to ${recipient.address}`,
      }));
      active();
      const signedHex = hex.max(200000).parse(typeof response === 'string' ? response : response?.signedTransaction).toLowerCase();
      const bytes = hexToBin(signedHex);
      const signed = decodeTransaction(bytes);
      if (typeof signed === 'string' || !binsAreEqual(encodeTransaction(signed), bytes)) throw new WalletOperationError('invalid-transaction', 'The connected wallet returned an invalid transaction.');
      const stripped = encodeTransaction({ ...signed, inputs: signed.inputs.map(item => ({ ...item, unlockingBytecode: Uint8Array.of() })) });
      if (!binsAreEqual(stripped, unsignedBytes)) throw new WalletOperationError('proposal-changed', 'The connected wallet changed the payment. Nothing was sent.');
      verifySigned(signed, selected.map(utxo => utxo.output));
      const fee = totals.value - outputs.reduce((sum, output) => sum + output.valueSatoshis, 0n);
      if (fee < BigInt(bytes.length)) throw new Error('The signed payment is larger than its fee allows. Prepare it again.');
      const hash = hashTransaction(bytes);
      const pending = this.#pendingRecord(hash, selected);
      const review = Object.freeze({
        id: String(++this.#sequence), kind: 'payment', network: this.network, address: recipient.address,
        amountBch: formatBch(amount), feeBch: formatBch(fee), feeSatoshis: fee.toString(),
        totalBch: formatBch(amount + fee), txid: hash, byteLength: bytes.length,
        expiresAt: Date.now() + REVIEW_MS, pending, signedBy: this.walletName,
      });
      return { kind: 'payment', review, hex: signedHex, inputs: selected, pending };
    });
  }

  async broadcast(id, options = {}) {
    this.#assertOpen();
    const draft = this.#draft;
    if (!draft || draft.review.id !== id || draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
    const persist = options?.persistPending;
    if (typeof persist !== 'function') throw new WalletOperationError('persist-required', 'Persist the pending record before broadcasting this payment.');
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    this.#busy = true;
    try {
      const owned = new Map((await this.#utxos()).map(utxo => [outpointId(utxo), utxo]));
      if (this.#draft !== draft) throw new Error('This review was cancelled.');
      if (!draft.inputs.every(input => owned.get(outpointId(input))?.valueSatoshis === input.valueSatoshis)) throw new WalletOperationError('input-spent', 'An input was spent. Prepare the payment again.');
      if (draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
      if (draft.pending.txid !== draft.review.txid || hashTransaction(hexToBin(draft.hex)) !== draft.review.txid || draft.hex.length !== draft.review.byteLength * 2) throw new WalletOperationError('draft-mismatch', 'Signed transaction does not match the approved review and pending record.');
      const signed = Object.freeze({ signedTransaction: draft.hex, txid: draft.pending.txid, network: draft.pending.network, kind: draft.pending.kind });
      try { await persist(draft.pending, signed); }
      catch (cause) { throw Object.assign(new WalletOperationError('persist-failed', 'The pending record could not be saved, so nothing was broadcast.'), { cause }); }
      this.#assertOpen();
      if (this.#draft !== draft) throw new Error('This review was cancelled.');
      if (draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
      this.#draft = undefined; // consume before submitting; double taps cannot resend
      this.#pending = draft.pending;
      try {
        const hash = new TransactionHash(await this.#client.request('blockchain.transaction.broadcast', [draft.hex])).toHex();
        if (hash !== draft.review.txid) throw new Error('Electrum returned an unexpected transaction hash.');
        return { txid: hash, network: this.network, kind: draft.kind };
      } catch (cause) { throw new BroadcastUncertainError(draft.review.txid, cause); }
    } finally { this.#busy = false; }
  }

  cancelSend() { this.#generation++; this.#draft = undefined; }

  get pending() { return this.#pending ?? null; }

  restorePending(record) {
    this.#assertOpen();
    const parsed = pendingRecord.parse(record);
    if (parsed.network !== this.network) throw new WalletOperationError('wrong-network', 'This pending record belongs to another network.');
    if (parsed.address !== this.address) throw new WalletOperationError('wrong-wallet', 'This pending record belongs to another wallet.');
    if (this.#pending && this.#pending.txid !== parsed.txid) throw new WalletOperationError('pending', 'Another pending transaction is already being resolved.');
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    this.cancelSend();
    this.#pending = this.#pendingRecord(parsed.txid, parsed.inputs, parsed.createdAt);
    return this.#pending;
  }

  async #findPending(record) {
    const watched = [...this.#entries.values()];
    for (const entry of watched) {
      const entryHistory = await this.#history(entry);
      const found = entryHistory.find(item => item.tx_hash === record.txid);
      if (!found) continue;
      const transaction = await this.#fetchTransaction(record.txid);
      const spent = new Set(transaction.inputs.map(input => `${binToHex(input.outpointTransactionHash)}:${input.outpointIndex}`));
      if (spent.size !== record.inputs.length || !record.inputs.every(input => spent.has(outpointId(input)))) throw new Error('Pending transaction inputs do not match the record.');
      return { status: found.height > 0 ? 'confirmed' : 'mempool', height: found.height > 0 ? found.height : 0 };
    }
    return undefined;
  }

  async #unspentIds() {
    const ids = new Set();
    for (const entry of this.#entries.values()) for (const item of unspentList.parse(await this.#client.request('blockchain.scripthash.listunspent', [entry.scriptHash, 'include_tokens']))) ids.add(`${item.tx_hash.toLowerCase()}:${item.tx_pos}`);
    return ids;
  }

  async #inputsAllSpent(record) {
    const ids = await this.#unspentIds();
    return record.inputs.every(input => !ids.has(outpointId(input)));
  }

  async #inputsAllUnspent(record) {
    const ids = await this.#unspentIds();
    return record.inputs.every(input => ids.has(outpointId(input)));
  }

  /** Resolve the pending record without broadcasting anything. */
  async checkPending() {
    await this.#scan();
    const record = this.#pending;
    if (!record) return null;
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    this.#busy = true;
    try {
      let found = await this.#findPending(record);
      let status;
      if (found) status = found.status;
      else if (await this.#inputsAllUnspent(record)) status = 'unknown';
      else {
        found = await this.#findPending(record);
        status = found ? found.status : 'conflicted';
      }
      this.#assertOpen();
      if (status !== 'unknown' && this.#pending === record) this.#pending = undefined;
      return Object.freeze({ txid: record.txid, kind: record.kind, status, height: found?.height ?? 0, resolved: status !== 'unknown' });
    } finally { this.#busy = false; }
  }

  async discardPending(hash) {
    const record = this.#pending;
    if (!record || record.txid !== txid.parse(hash)) throw new WalletOperationError('no-pending', 'There is no such pending transaction.');
    const result = await this.checkPending();
    if (result.status === 'unknown' && this.#pending === record) this.#pending = undefined;
    return Object.freeze({ ...result, discarded: result.status === 'unknown' });
  }

  async lookupTransaction(hash) {
    await this.#verifyNetwork();
    const value = new TransactionHash(hash).toHex();
    const raw = hex.parse(await this.#client.request('blockchain.transaction.get', [value, false]));
    if (hashTransaction(hexToBin(raw)) !== value) throw new Error('Transaction lookup returned the wrong hash.');
    return { txid: value, found: true };
  }

  close() { this.#closed = true; this.#generation++; this.#draft = undefined; this.#client.close(); }
}
