import type {ElectrumTransport, Network, PaymentReview, PendingRecord, PendingStatus, BroadcastResult} from './core.js';

export declare const CONNECTED_PATH: 'connected';

/** One hdwalletv1 branch xpub shared by the connected wallet. */
export interface ConnectedPathXpub { name: string; xpub: string }

/** What the connected wallet is asked to sign. It must not broadcast. */
export interface ConnectedSignRequest {
  /** Unsigned transaction, hex. */
  transaction: string;
  /** Inputs merged with the outputs they spend (WalletConnect / WizardConnect shape). */
  sourceOutputs: ReadonlyArray<{
    outpointTransactionHash: Uint8Array; outpointIndex: number; sequenceNumber: number;
    unlockingBytecode: Uint8Array; lockingBytecode: Uint8Array; valueSatoshis: bigint;
  }>;
  /** [input index, branch name, address index] for every input. */
  inputPaths: ReadonlyArray<[number, 'receive' | 'change', number]>;
  broadcast: false;
  userPrompt: string;
}

export interface ConnectedWalletOptions {
  network?: Network;
  /** `receive` is required; `change` is used for change when present. */
  paths: ReadonlyArray<ConnectedPathXpub>;
  /** Resolves to the signed transaction hex (or `{signedTransaction}`). */
  signer: (request: Readonly<ConnectedSignRequest>) => Promise<string | {signedTransaction: string}>;
  walletName?: string;
  gapLimit?: number;
  client?: ElectrumTransport;
  endpoint?: string;
}

export interface ConnectedPaymentReview extends PaymentReview { readonly signedBy: string | null }

export interface ConnectedSession {
  readonly kind: 'connected';
  readonly network: Network;
  readonly path: typeof CONNECTED_PATH;
  /** receive/0: the stable identity of this connection. */
  readonly address: string;
  readonly tokenAddress: string;
  /** First unused receive address after the latest refresh. */
  receiveAddress: string;
  readonly walletName: string | null;
  readonly pending: PendingRecord | null;
  refresh(): Promise<Readonly<{address: string; receiveAddress: string; network: Network; balanceSatoshis: string; balanceBch: string; outputCount: number}>>;
  /** Builds the payment and waits for the connected wallet to sign it. */
  prepareSend(payment: {address: string; amountBch: string}): Promise<ConnectedPaymentReview>;
  broadcast(id: string, options: {persistPending: (record: PendingRecord, transaction: Readonly<{signedTransaction: string; txid: string; network: Network; kind: 'payment'}>) => Promise<void> | void}): Promise<BroadcastResult>;
  cancelSend(): void;
  restorePending(record: PendingRecord): PendingRecord;
  checkPending(): Promise<PendingStatus | null>;
  discardPending(txid: string): Promise<PendingStatus & {discarded: boolean}>;
  lookupTransaction(txid: string): Promise<{txid: string; found: true}>;
  close(): void;
}

export declare function createConnectedSession(options: ConnectedWalletOptions): ConnectedSession;
