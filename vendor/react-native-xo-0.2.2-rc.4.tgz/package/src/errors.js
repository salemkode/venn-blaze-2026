/** A failed broadcast may already be on the network: inspect txid, never retry automatically. */
export class BroadcastUncertainError extends Error {
  constructor(txid, cause) {
    super(`Broadcast outcome needs checking. Look up transaction ${txid} before sending again.`, { cause });
    this.name = 'BroadcastUncertainError'; this.txid = txid;
  }
}

/** A refused wallet operation. `code` is stable for UI handling; nothing was broadcast. */
export class WalletOperationError extends Error {
  constructor(code, message, details) {
    super(message);
    this.name = 'WalletOperationError'; this.code = code;
    if (details) this.details = Object.freeze({ ...details });
  }
}
