import {
  ConsensusBch2025, bigIntToCompactUint, binToBase64, binToHex, binsAreEqual, cashAddressToLockingBytecode, createVirtualMachineBCH,
  createVirtualMachineBch2025, createVirtualMachineBch2026, decodeAuthenticationInstructions,
  decodeBip39Mnemonic, decodeCashAddress, decodeTransaction, deriveHdPath, deriveHdPathRelative, deriveHdPublicNode,
  deriveHdPrivateNodeFromSeed, deriveSeedFromBip39Mnemonic, encodeDataPush, encodeLockingBytecodeP2sh32, encodeTransaction,
  encodeHdPublicKey, flattenBinArray, generateSigningSerializationBch, generateTransaction, getDustThreshold, hash256,
  hashTransaction, hexToBin, lockingBytecodeToCashAddress, privateKeyToP2pkhLockingBytecode,
  publicKeyToP2pkhLockingBytecode, secp256k1, sha256, utf8ToBin, walletTemplateP2pkhNonHd, walletTemplateToCompilerBCH,
} from '@bitauth/libauth';
import { PrivateKey, Satoshis, TransactionHash } from '@xo-cash/primitives';
import { z } from 'zod';
import { ElectrumClient } from './electrum.js';
import { BroadcastUncertainError, WalletOperationError } from './errors.js';
import { FOCUS_GARDEN_ARTIFACT } from './focus-garden/artifact.js';
import {
  BATON_SATOSHIS, TREE_SATOSHIS, batonToken, encodeFocusGardenUnlocking, focusGardenAddress,
  focusGardenRedeemBytecode, parseCategory, readBatonOutput, treeToken, verifyCanonicalGenesis,
} from './focus-garden/contract.js';
import {
  GENESIS_STATE, UNIT_SECONDS, checkUnits, encodeGardenState, encodeTreeCommitment, relativeLockSequence,
} from './focus-garden/protocol.js';
import { JOURNAL_CHUNK_BYTES, JOURNAL_MAX_BYTES, JOURNAL_MAX_CHUNKS, assembleJournal, decodeJournalOutput, encodeJournalOutput, planJournalPublication } from './journal.js';
import { NETWORKS, networkName } from './networks.js';
import { tokenPolicySelection, tokenPolicyEvidence, freezeTokenPolicy, resolveTokenPolicy, assertTokenPolicyContinuation, assertTokenPolicyContext } from './token-policy.js';
export { NETWORKS } from './networks.js';
export { BroadcastUncertainError, WalletOperationError } from './errors.js';

const REVIEW_MS = 120000;
const SIGHASH_ALL_FORKID = 0x41;
const SIGNING_TYPES = Object.freeze({ 'SIGHASH_ALL|FORKID': SIGHASH_ALL_FORKID, 'SIGHASH_ALL|FORKID|UTXOS': 0x61 });
const XPUB_BRANCHES = Object.freeze({ receive: 0, change: 1, defi: 7 });
const P2PKH_UNLOCKING_BYTES = 100; // push(64-byte Schnorr + type) + push(33-byte key)
const P2PKH_DUST = 546n;
const MAX_CONTRACT_FUNDING_INPUTS = 20;
const GENESIS_HISTORY_SCAN = 25;
const COVENANT_CANDIDATES = 50;
const FINAL_SEQUENCE = 0xffffffff;
const GARDEN_KINDS = ['garden-genesis', 'garden-open', 'garden-complete', 'garden-abandon'];
const KINDS = ['payment', ...GARDEN_KINDS, 'journal-chunk', 'transaction', 'token-payment'];

const hdIndex = z.number().int().min(0).max(0x7fffffff);
const addressSelection = z.object({ change: z.union([z.literal(0), z.literal(1), z.literal(7)]).default(0), index: hdIndex.default(0) }).strict();
const hdSelection = addressSelection.extend({ account: hdIndex.default(0) });
const xpubSelection = z.object({ scope: z.enum(['account', 'receive', 'change', 'defi']), acknowledgePrivacy: z.literal(true) }).strict();
const visibleText = z.string().refine(value => !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f\u202a-\u202e\u2066-\u2069]/.test(value), 'Unsupported hidden control character.').refine(value => !Array.from(value).some(character => character.length === 1 && character.charCodeAt(0) >= 0xd800 && character.charCodeAt(0) <= 0xdfff), 'Malformed Unicode.');
const peerIdentity = visibleText.refine(value => !/[\r\n\t]/.test(value), 'Peer identity must be one line.').refine(value => value.trim().length > 0).pipe(z.string().min(1).max(200));
const messageProposal = z.object({ peer: peerIdentity, message: visibleText.pipe(z.string().max(4096)) }).strict();
const transactionProposal = z.object({
  version: z.literal(1), network: networkName,
  unsignedTransaction: z.string().min(20).max(200000).regex(/^(?:[a-fA-F0-9]{2})+$/),
  maxFeeSatoshis: z.string().regex(/^[1-9][0-9]{0,5}$/).transform(BigInt).refine(value => value <= 100000n),
  signingType: z.enum(['SIGHASH_ALL|FORKID', 'SIGHASH_ALL|FORKID|UTXOS']).default('SIGHASH_ALL|FORKID'),
}).strict();

const hex = z.string().regex(/^(?:[a-fA-F0-9]{2})+$/);
const txid = z.string().regex(/^[a-fA-F0-9]{64}$/).transform(value => value.toLowerCase());
const lowercaseTxid = z.string().regex(/^[a-f0-9]{64}$/);
const tokenAmount = z.string().max(19).regex(/^(0|[1-9][0-9]*)$/).transform(BigInt).refine(value => value <= 9223372036854775807n);
const nftSelection = z.object({ txid: lowercaseTxid, index: z.number().int().min(0).max(0xffffffff), capability: z.enum(['none', 'mutable', 'minting']), commitment: z.string().max(128 * 2).regex(/^(?:[a-f0-9]{2})*$/) }).strict();
const tokenPayment = z.object({ address: z.string().trim().min(1), category: lowercaseTxid, amount: tokenAmount, nft: nftSelection.optional(), consensusPolicy: tokenPolicySelection.optional() }).strict().refine(value => value.amount > 0n || value.nft !== undefined, 'Select a positive token amount or an NFT.');
const unspentList = z.array(z.object({
  tx_hash: z.string().length(64).regex(/^[a-fA-F0-9]+$/),
  tx_pos: z.number().int().min(0).max(0xffffffff),
  value: z.number().int().safe().nonnegative().max(2100000000000000),
  height: z.number().int(), token_data: z.unknown().optional(),
})).max(200);
const historyList = z.array(z.object({ tx_hash: txid, height: z.number().int() }).passthrough()).max(20000);
const headerTip = z.object({ height: z.number().int().nonnegative(), hex: hex.length(160) }).passthrough();
const headerRange = z.object({ count: z.number().int().positive(), hex }).passthrough();
const outpoint = z.object({ txid, index: z.number().int().min(0).max(0xffffffff) }).strict();
const pendingRecord = z.object({
  version: z.literal(1), network: networkName, kind: z.enum(KINDS), txid,
  path: z.string().max(80).optional(),
  address: z.string().max(120).optional(),
  consensusPolicy: tokenPolicyEvidence.optional(),
  category: txid.nullable(), inputs: z.array(outpoint).min(1).max(100),
  createdAt: z.number().int().nonnegative(),
  publication: z.object({ id: z.string().regex(/^[0-9a-f]{32}$/), index: z.number().int().min(0), count: z.number().int().min(1).max(JOURNAL_MAX_CHUNKS) }).strict().nullable(),
}).strict();

let verifiers;
/** Contract and journal transactions must pass both current BCH standard VMs. */
function verifyStandard(transaction, sourceOutputs, policy) {
  if (policy) {
    const result = createVirtualMachineBch2026(true).verify({transaction,sourceOutputs});
    if (result !== true) throw new Error(`Signed transaction validation failed (BCH2026 subset): ${result}`);
    return; // BCH2025 rejection of41..128bytes is a diagnostic, not an authority.
  }
  if (!verifiers) verifiers = [['BCH 2025', createVirtualMachineBch2025(true)], ['BCH 2026', createVirtualMachineBch2026(true)]];
  for (const [name, vm] of verifiers) {
    const result = vm.verify({ transaction, sourceOutputs });
    if (result !== true) throw new Error(`Signed transaction validation failed (${name}): ${result}`);
  }
}

export function parseBch(value) { return Satoshis.fromBchString(z.string().trim().parse(value)).toBigInt(); }
export function formatBch(value) { return new Satoshis(value).toBchString(); }

export function validateRecipient(address, network) {
  const config = NETWORKS[networkName.parse(network)];
  const value = z.string().trim().min(1).parse(address);
  const decoded = decodeCashAddress(value);
  if (typeof decoded === 'string') throw new Error('Enter a complete CashAddress, including its network prefix.');
  if (decoded.prefix !== config.prefix) throw new Error(`Use a ${config.prefix}: address for ${config.label}.`);
  if (!(decoded.type === 'p2pkh' && decoded.payload.length === 20) && !(decoded.type === 'p2sh' && [20, 32].includes(decoded.payload.length))) throw new Error('This BCH-only wallet supports P2PKH, P2SH20 and P2SH32 recipients without token support flags.');
  const result = cashAddressToLockingBytecode(value);
  if (typeof result === 'string') throw new Error('Invalid CashAddress.');
  return { address: value.toLowerCase(), bytecode: result.bytecode };
}

export function validateTokenRecipient(address, network) {
  const config = NETWORKS[networkName.parse(network)];
  const value = z.string().trim().min(1).parse(address);
  const decoded = decodeCashAddress(value);
  if (typeof decoded === 'string' || decoded.prefix !== config.prefix) throw new WalletOperationError('wrong-network', 'Use a full token-aware CashAddress on the selected network.');
  if (!(decoded.type === 'p2pkhWithTokens' && decoded.payload.length === 20) && !(decoded.type === 'p2shWithTokens' && [20, 32].includes(decoded.payload.length))) throw new WalletOperationError('token-address-required', 'Token payments require a token-aware P2PKH, P2SH20 or P2SH32 CashAddress.');
  const result = cashAddressToLockingBytecode(value);
  if (typeof result === 'string') throw new WalletOperationError('token-address-required', 'Invalid token address.');
  return { address: value.toLowerCase(), bytecode: result.bytecode };
}

export function createWalletSession({ mnemonic, network = 'chipnet', client, endpoint, allowMainnetContracts = false, hd = {} } = {}) {
  const selected = networkName.parse(network);
  const selection = hdSelection.parse(hd);
  const mainnetContracts = z.boolean().parse(allowMainnetContracts);
  const phrase = z.string().trim().transform(value => value.normalize('NFKD').split(/\s+/).join(' ')).parse(mnemonic);
  const entropy = decodeBip39Mnemonic(phrase);
  if (typeof entropy === 'string') throw new Error('The recovery phrase is invalid. Check its words and checksum.');
  entropy.fill(0);
  const seed = deriveSeedFromBip39Mnemonic(phrase);
  const master = deriveHdPrivateNodeFromSeed(seed);
  const accountPath = `m/44'/${NETWORKS[selected].coinType}'/${selection.account}'`;
  try {
    const account = deriveHdPath(master, accountPath);
    try {
      const node = deriveHdPathRelative(account, `${selection.change}/${selection.index}`);
      try {
        const key = new PrivateKey(node.privateKey);
        try {
          return new WalletSession(key, selected, `${accountPath}/${selection.change}/${selection.index}`, client || new ElectrumClient(endpoint || NETWORKS[selected].endpoint), mainnetContracts, { node: deriveHdPublicNode(account), path: accountPath });
        } catch (error) { key.destroy(); throw error; }
      } finally { node.privateKey.fill(0); }
    } finally { account.privateKey.fill(0); }
  } finally { seed.fill(0); master.privateKey.fill(0); }
}

const headerTime = header => header[68] | (header[69] << 8) | (header[70] << 16) | (header[71] * 2 ** 24);
const outpointId = item => `${item.txid}:${item.index}`;
const sumSatoshis = values => values.reduce((total, value) => total + value, 0n);

class WalletSession {
  #key;
  #publicKey;
  #client;
  #verified;
  #closed = false;
  #busy = false;
  #draft;
  #generation = 0;
  #sequence = 0;
  #locking;
  #scriptHash;
  #pending;
  #allowMainnetContracts;
  #lastCategory;
  #genesis = new Map();
  #account;

  constructor(key, network, path, client, allowMainnetContracts, account) {
    this.#account = account;
    this.#key = key; this.#client = client; this.#allowMainnetContracts = allowMainnetContracts;
    this.network = network; this.path = path;
    const bytes = key.toBytes();
    this.#locking = privateKeyToP2pkhLockingBytecode({ privateKey: bytes });
    const publicKey = secp256k1.derivePublicKeyCompressed(bytes); bytes.fill(0);
    if (typeof publicKey === 'string') throw new Error(publicKey);
    this.#publicKey = publicKey;
    const address = lockingBytecodeToCashAddress({ bytecode: this.#locking, prefix: NETWORKS[network].prefix });
    if (typeof address === 'string') throw new Error(address);
    this.address = address.address;
    const tokenAddress = lockingBytecodeToCashAddress({ bytecode: this.#locking, prefix: NETWORKS[network].prefix, tokenSupport: true });
    if (typeof tokenAddress === 'string') throw new Error(tokenAddress);
    this.tokenAddress = tokenAddress.address;
    this.publicKey = binToHex(publicKey); // public bytes only; the private key never leaves this session
    this.#scriptHash = this.#scriptHashOf(this.#locking);
    this.focusGarden = Object.freeze({
      artifact: FOCUS_GARDEN_ARTIFACT,
      covenantAddress: category => focusGardenAddress({ ownerPublicKey: this.#publicKey, category, prefix: NETWORKS[this.network].prefix }),
      readGarden: category => this.#readGarden(category),
      prepareGenesis: () => this.#prepare(() => this.#buildGenesis()),
      prepareOpen: options => this.#prepare(() => this.#buildOpen(options)),
      prepareComplete: options => this.#prepare(() => this.#buildClose('garden-complete', options)),
      prepareAbandon: options => this.#prepare(() => this.#buildClose('garden-abandon', options)),
      broadcast: (id, options) => this.#broadcast(id, options, GARDEN_KINDS),
      cancel: () => this.cancelSend(),
    });
    this.journal = Object.freeze({
      plan: ciphertext => this.#planJournal(ciphertext),
      preparePublish: options => this.#prepare(() => this.#buildJournal(options)),
      broadcast: (id, options) => this.#broadcast(id, options, ['journal-chunk']),
      cancel: () => this.cancelSend(),
      read: options => this.#readJournal(options),
    });
    // Identity cannot be retargeted after construction. Metro lowers private
    // fields to ordinary hidden properties; freezing the instance would freeze
    // draft/operation state too, so protect only these public members.
    Object.defineProperties(this, Object.fromEntries(['network', 'path', 'address', 'tokenAddress', 'publicKey', 'focusGarden', 'journal'].map(name => [name, { writable: false, configurable: false }])));
  }

  #assertOpen() { if (this.#closed) throw new Error('Wallet session is closed.'); }
  /** Public BIP32 children only. This does not select, scan, or spend that address. */
  deriveAddress(options = {}) {
    this.#assertOpen();
    const { change, index } = addressSelection.parse(options);
    const node = deriveHdPathRelative(this.#account.node, `${change}/${index}`);
    const locking = publicKeyToP2pkhLockingBytecode({ publicKey: node.publicKey });
    const address = lockingBytecodeToCashAddress({ bytecode: locking, prefix: NETWORKS[this.network].prefix });
    if (typeof address === 'string') throw new Error(address);
    return Object.freeze({ network: this.network, path: `${this.#account.path}/${change}/${index}`, address: address.address, publicKey: binToHex(node.publicKey), lockingBytecode: binToHex(locking) });
  }
  /** Privacy boundary: call only after host approval of this exact peer and scope. */
  exportXpub(options) {
    this.#assertOpen();
    const { scope } = xpubSelection.parse(options);
    const branch = scope === 'account' ? null : XPUB_BRANCHES[scope];
    const node = branch === null ? this.#account.node : deriveHdPathRelative(this.#account.node, String(branch));
    const { hdPublicKey } = encodeHdPublicKey({ node, network: this.network === 'mainnet' ? 'mainnet' : 'testnet' });
    return Object.freeze({ scope, network: this.network, path: branch === null ? this.#account.path : `${this.#account.path}/${branch}`, xpub: hdPublicKey });
  }
  #scriptHashOf(locking) { return binToHex(sha256.hash(locking).reverse()); }
  #assertContractsAllowed() {
    if (this.network === 'mainnet' && !this.#allowMainnetContracts) throw new WalletOperationError('mainnet-disabled', 'Contract and journal transactions are disabled on Mainnet for this session.');
  }

  async #verifyNetwork() {
    this.#assertOpen();
    if (!this.#verified) this.#verified = (async () => {
      await this.#client.request('server.version', ['react-native-xo', '1.4']);
      const config = NETWORKS[this.network];
      const header = hex.length(160).parse(await this.#client.request('blockchain.block.header', [config.checkpointHeight]));
      if (hashTransaction(hexToBin(header)) !== config.checkpointHash) throw new Error('Electrum server is on the wrong network.');
    })();
    await this.#verified;
    this.#assertOpen();
  }

  async #fetchTransaction(hash) {
    const raw = hex.parse(await this.#client.request('blockchain.transaction.get', [hash, false]));
    const bytes = hexToBin(raw);
    if (hashTransaction(bytes) !== hash) throw new Error('Electrum returned a transaction with the wrong hash.');
    const transaction = decodeTransaction(bytes);
    if (typeof transaction === 'string') throw new Error('Electrum returned an invalid transaction.');
    return transaction;
  }

  async #listUnspent(scriptHash) {
    const list = unspentList.parse(await this.#client.request('blockchain.scripthash.listunspent', [scriptHash, 'include_tokens']));
    const seen = new Set();
    for (const item of list) {
      const id = `${item.tx_hash.toLowerCase()}:${item.tx_pos}`;
      if (seen.has(id)) throw new Error('Electrum returned duplicate outputs.');
      seen.add(id);
    }
    return list;
  }

  /** Every returned output was re-derived from its hash-verified source transaction. */
  async #verifiedOutput(item, locking) {
    const hash = item.tx_hash.toLowerCase();
    const transaction = await this.#fetchTransaction(hash);
    const output = transaction.outputs[item.tx_pos];
    if (!output || output.valueSatoshis !== BigInt(item.value) || !binsAreEqual(output.lockingBytecode, locking)) throw new Error('Electrum output does not match the wallet or amount.');
    const coinbase = transaction.inputs.some(input => input.outpointTransactionHash.every(byte => byte === 0));
    return { txid: new TransactionHash(hash).toHex(), index: item.tx_pos, valueSatoshis: new Satoshis(item.value).toBigInt(), height: item.height, output, coinbase };
  }

  /** BCH-only, non-coinbase owner outputs. Token outputs (trees) are never funding. */
  async #utxos() {
    await this.#verifyNetwork();
    const verified = [];
    for (const item of await this.#listUnspent(this.#scriptHash)) {
      if (item.token_data || item.height < 0) continue;
      const utxo = await this.#verifiedOutput(item, this.#locking);
      // CashTokens are never spent as funding, even if the server omits
      // token_data. Coinbase maturity is intentionally unsupported.
      if (utxo.output.token || utxo.coinbase) continue;
      verified.push(utxo);
    }
    this.#assertOpen();
    return verified.sort((a, b) => a.txid.localeCompare(b.txid) || a.index - b.index);
  }

  /** Token hints are untrusted; decode every bounded owner source transaction. */
  async #ownedOutputs() {
    await this.#verifyNetwork();
    const verified = [];
    for (const item of await this.#listUnspent(this.#scriptHash)) {
      if (item.height < 0) continue;
      const utxo = await this.#verifiedOutput(item, this.#locking);
      if (!utxo.coinbase) verified.push(utxo);
    }
    this.#assertOpen();
    return verified.sort((a, b) => a.txid.localeCompare(b.txid) || a.index - b.index);
  }

  async refreshTokens(options = {}) {
    this.#assertOpen();
    const selected = z.object({consensusPolicy: tokenPolicySelection.optional()}).strict().parse(options);
    const policy = await resolveTokenPolicy(selected.consensusPolicy,this.network,this.#client);
    const outputs = (await this.#ownedOutputs()).filter(utxo => utxo.output.token);
    const categories = [...new Set(outputs.map(utxo => binToHex(utxo.output.token.category)))].sort().map(category => {
      const group = outputs.filter(utxo => binToHex(utxo.output.token.category) === category);
      const nfts = group.filter(utxo => utxo.output.token.nft).map(utxo => Object.freeze({ txid: utxo.txid, index: utxo.index, capability: utxo.output.token.nft.capability, commitment: binToHex(utxo.output.token.nft.commitment), amount: utxo.output.token.amount.toString(), valueSatoshis: utxo.valueSatoshis.toString(), commitmentSupported: utxo.output.token.nft.commitment.length <= (policy?.maximumCommitmentBytes ?? ConsensusBch2025.maximumTokenCommitmentLength) }));
      return Object.freeze({ category, amount: sumSatoshis(group.map(utxo => utxo.output.token.amount)).toString(), backingSatoshis: sumSatoshis(group.map(utxo => utxo.valueSatoshis)).toString(), outputCount: group.length, nfts: Object.freeze(nfts) });
    });
    return Object.freeze({ network: this.network, path: this.path, address: this.tokenAddress, categories: Object.freeze(categories), ...(policy ? {consensusPolicy:policy} : {}) });
  }

  #covenant(category) {
    const redeem = focusGardenRedeemBytecode({ ownerPublicKey: this.#publicKey, category });
    const locking = encodeLockingBytecodeP2sh32(hash256(redeem));
    return { redeem, locking, scriptHash: this.#scriptHashOf(locking), address: focusGardenAddress({ ownerPublicKey: this.#publicKey, category, prefix: NETWORKS[this.network].prefix }) };
  }

  /** Verified minting batons of `category` at this owner's covenant. */
  async #batons(category, covenant) {
    const batons = [];
    let fetched = 0;
    for (const item of await this.#listUnspent(covenant.scriptHash)) {
      const reported = item.token_data && typeof item.token_data === 'object' ? item.token_data.category : undefined;
      if (typeof reported === 'string' && reported.toLowerCase() !== category) continue; // a foreign token
      if (++fetched > COVENANT_CANDIDATES) throw new WalletOperationError('covenant-spam', 'Too many unrelated outputs at the garden covenant to verify safely.');
      const utxo = await this.#verifiedOutput(item, covenant.locking);
      const state = readBatonOutput(utxo.output, category, covenant.locking);
      if (state) batons.push({ ...utxo, state });
    }
    return batons;
  }

  /** Find and check the category genesis once per session. Fails closed. */
  async #verifyGenesis(category, covenant) {
    if (this.#genesis.has(category)) return this.#genesis.get(category);
    const history = historyList.parse(await this.#client.request('blockchain.scripthash.get_history', [covenant.scriptHash]));
    const ordered = [...history.filter(item => item.height > 0).sort((a, b) => a.height - b.height), ...history.filter(item => item.height <= 0)];
    for (const item of ordered.slice(0, GENESIS_HISTORY_SCAN)) {
      const transaction = await this.#fetchTransaction(item.tx_hash);
      const [first] = transaction.inputs;
      if (!first || binToHex(first.outpointTransactionHash) !== category || first.outpointIndex !== 0) continue;
      verifyCanonicalGenesis({ transaction, category, covenantLocking: covenant.locking });
      const genesis = Object.freeze({ txid: item.tx_hash, height: item.height > 0 ? item.height : 0 });
      this.#genesis.set(category, genesis);
      return genesis;
    }
    throw new WalletOperationError('not-canonical', 'The garden genesis transaction could not be found and verified; its trees cannot be trusted.');
  }

  async #canonicalBaton(category) {
    await this.#verifyNetwork();
    const covenant = this.#covenant(category);
    const batons = await this.#batons(category, covenant);
    if (batons.length > 1) throw new WalletOperationError('not-canonical', 'More than one minting baton exists for this garden.');
    if (!batons.length) return { covenant, baton: undefined };
    const genesis = await this.#verifyGenesis(category, covenant);
    this.#assertOpen();
    return { covenant, baton: batons[0], genesis };
  }

  async #headers(start, count) {
    const range = headerRange.parse(await this.#client.request('blockchain.block.headers', [start, count]));
    if (range.count !== count || range.hex.length !== count * 160) throw new Error('Electrum returned an incomplete header range.');
    const headers = Array.from({ length: count }, (_, index) => hexToBin(range.hex.slice(index * 160, (index + 1) * 160)));
    for (let index = 1; index < headers.length; index++) {
      if (!binsAreEqual(headers[index].slice(4, 36), hash256(headers[index - 1]))) throw new Error('Electrum returned unlinked block headers.');
    }
    return headers;
  }

  /** BIP113 median-time-past of the block at `height` (median of up to 11 timestamps). */
  async #medianTimePast(height) {
    const start = Math.max(0, height - 10);
    const headers = await this.#headers(start, height - start + 1);
    const times = headers.map(headerTime).sort((a, b) => a - b);
    return { mtp: times[Math.floor(times.length / 2)], last: binToHex(headers[headers.length - 1]) };
  }

  async #tip() {
    const tip = headerTip.parse(await this.#client.request('blockchain.headers.subscribe', []));
    const { mtp, last } = await this.#medianTimePast(tip.height);
    if (last !== tip.hex.toLowerCase()) throw new Error('Electrum tip header does not match its header range.');
    return { height: tip.height, mtp };
  }

  /**
   * BIP68 time lock: a node accepts the `complete` spend once the tip's MTP is
   * at least MTP(confirmation height - 1) + units * 512 seconds.
   */
  async #timing(baton) {
    const tip = await this.#tip();
    const confirmed = baton.height > 0;
    const confirmations = confirmed ? Math.max(0, tip.height - baton.height + 1) : 0;
    if (!baton.state.open || !confirmed) return { tip, confirmations, claimableAt: null, claimable: false };
    const { mtp } = await this.#medianTimePast(baton.height - 1);
    const claimableAt = mtp + baton.state.units * UNIT_SECONDS;
    return { tip, confirmations, claimableAt, claimable: tip.mtp >= claimableAt };
  }

  async #readGarden(category) {
    this.#assertOpen();
    const id = category === undefined || category === null ? this.#lastCategory : parseCategory(category);
    if (!id) return null;
    const { covenant, baton, genesis } = await this.#canonicalBaton(id);
    if (!baton) return null;
    const { tip, confirmations, claimableAt, claimable } = await this.#timing(baton);
    this.#assertOpen();
    const { state } = baton;
    return Object.freeze({
      network: this.network, category: id, covenantAddress: covenant.address, genesisTxid: genesis.txid,
      outpoint: Object.freeze({ txid: baton.txid, index: baton.index }), valueSatoshis: baton.valueSatoshis.toString(),
      state: Object.freeze({ open: state.open, completed: state.completed, units: state.open ? state.units : 0, record: state.open ? binToHex(state.record) : null, minimumWaitSeconds: state.open ? state.units * UNIT_SECONDS : 0 }),
      height: baton.height > 0 ? baton.height : 0, confirmations, tipHeight: tip.height, mtp: tip.mtp, claimableAt, claimable,
    });
  }

  async refresh() {
    const utxos = await this.#utxos();
    if (this.#pending && await this.#inputsAllSpent(this.#pending)) this.#pending = undefined;
    const total = utxos.reduce((sum, utxo) => sum + utxo.valueSatoshis, 0n);
    return Object.freeze({ address: this.address, network: this.network, balanceSatoshis: total.toString(), balanceBch: formatBch(total), outputCount: utxos.length });
  }

  /** One latch for every prepared transaction: payments, garden actions, and journal chunks. */
  async #prepare(build) {
    this.#assertOpen();
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    if (this.#pending) throw new WalletOperationError('pending', 'Resolve the pending transaction before preparing another one.');
    this.#busy = true;
    this.#draft = undefined;
    const generation = ++this.#generation;
    try {
      const draft = await build();
      this.#assertOpen();
      if (generation !== this.#generation) throw new WalletOperationError('cancelled', 'The review was cancelled.');
      this.#draft = draft;
      return draft.review;
    } finally { this.#busy = false; }
  }

  #pendingRecord(kind, hash, inputs, category = null, publication = null, createdAt = Date.now(), policy = null) {
    return Object.freeze({ version: 1, network: this.network, path: this.path, address: this.address, kind, txid: hash, category, inputs: Object.freeze(inputs.map(item => Object.freeze({ txid: item.txid, index: item.index }))), createdAt, publication: publication && Object.freeze({ ...publication }), ...(policy ? {consensusPolicy:policy} : {}) });
  }

  /** Review exact UTF-8 text in the host. Never signs hashes or transactions. */
  prepareMessage(proposal) {
    return this.#prepare(async () => {
      const { peer, message } = messageProposal.parse(proposal);
      const bytes = utf8ToBin(message);
      if (bytes.length > 4096) throw new WalletOperationError('message-size', 'Messages are limited to 4096 UTF-8 bytes.');
      const magic = utf8ToBin('Bitcoin Signed Message:\n');
      const digest = hash256(flattenBinArray([bigIntToCompactUint(BigInt(magic.length)), magic, bigIntToCompactUint(BigInt(bytes.length)), bytes]));
      const review = Object.freeze({ id: String(++this.#sequence), kind: 'message', network: this.network, address: this.address, publicKey: this.publicKey, peer, message, byteLength: bytes.length, expiresAt: Date.now() + REVIEW_MS });
      return { kind: 'message', review, digest };
    });
  }

  /** Human approval boundary; a message signature is relayable and cannot be revoked. */
  exportMessageSignature(id, options) {
    this.#assertOpen();
    const { peer } = z.object({ peer: peerIdentity }).strict().parse(options);
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    const draft = this.#draft;
    if (!draft || draft.review.id !== id || draft.review.expiresAt < Date.now()) throw new WalletOperationError('review-expired', 'Review expired. Prepare it again.');
    if (draft.kind !== 'message') throw new WalletOperationError('wrong-kind', 'This is not a message review.');
    if (draft.review.peer !== peer) throw new WalletOperationError('wrong-peer', 'The approved peer does not match the message review.');
    this.#draft = undefined;
    const keyBytes = this.#key.toBytes();
    try {
      const signed = secp256k1.signMessageHashRecoverableCompact(keyBytes, draft.digest);
      if (typeof signed === 'string') throw new WalletOperationError('message-signing', 'Message signing failed.');
      const recovered = secp256k1.recoverPublicKeyCompressed(signed.signature, signed.recoveryId, draft.digest);
      if (typeof recovered === 'string' || !binsAreEqual(recovered, this.#publicKey)) throw new WalletOperationError('message-signing', 'Message signature recovery failed.');
      const signature = binToBase64(flattenBinArray([Uint8Array.of(31 + signed.recoveryId), signed.signature]));
      return Object.freeze({ kind: 'message', network: this.network, address: this.address, publicKey: this.publicKey, peer, message: draft.review.message, signature, encoding: 'base64', algorithm: 'bitcoin-signed-message' });
    } finally { keyBytes.fill(0); }
  }

  prepareSend({ address, amountBch }) {
    return this.#prepare(async () => {
      const recipient = validateRecipient(address, this.network);
      const amount = parseBch(amountBch);
      if (amount < P2PKH_DUST) throw new Error('Minimum payment is 0.00000546 BCH (546 satoshis).');
      if (amount < getDustThreshold({ lockingBytecode: recipient.bytecode, valueSatoshis: amount })) throw new WalletOperationError('dust', 'This recipient requires a higher amount to avoid a dust output.');
      const available = await this.#utxos();
      const selected = [];
      const totals = { value: 0n, fee: 0n };
      for (const utxo of available) {
        selected.push(utxo); totals.value += utxo.valueSatoshis;
        // 1 sat/byte, conservative 148-byte inputs and two standard outputs.
        totals.fee = BigInt(10 + selected.length * 148 + 8 + 1 + recipient.bytecode.length + 34);
        if (totals.value >= amount + totals.fee) break;
        if (selected.length >= 100) throw new Error('Consolidate outputs before sending: maximum 100 inputs.');
      }
      if (totals.value < amount + totals.fee) throw new Error('Insufficient BCH for this amount and its network fee.');
      const change = totals.value - amount - totals.fee;
      const outputs = [{ lockingBytecode: recipient.bytecode, valueSatoshis: amount }, ...(change >= P2PKH_DUST ? [{ lockingBytecode: this.#locking, valueSatoshis: change }] : [])];
      const keyBytes = this.#key.toBytes();
      let generated;
      try {
        generated = generateTransaction({
          version: 2, locktime: 0,
          inputs: selected.map(utxo => ({
            outpointTransactionHash: hexToBin(utxo.txid), outpointIndex: utxo.index, sequenceNumber: FINAL_SEQUENCE,
            unlockingBytecode: { compiler: walletTemplateToCompilerBCH(walletTemplateP2pkhNonHd), script: 'unlock', valueSatoshis: utxo.valueSatoshis, data: { keys: { privateKeys: { key: keyBytes } } } },
          })), outputs,
        });
      } finally { keyBytes.fill(0); }
      if (!generated.success) throw new Error('Transaction signing failed.');
      const verification = createVirtualMachineBCH().verify({ transaction: generated.transaction, sourceOutputs: selected.map(utxo => utxo.output) });
      if (verification !== true) throw new Error(`Signed transaction validation failed: ${verification}`);
      const bytes = encodeTransaction(generated.transaction);
      const fee = totals.value - outputs.reduce((sum, output) => sum + output.valueSatoshis, 0n);
      if (fee < BigInt(bytes.length) || fee > totals.fee + 545n) throw new Error('Unexpected transaction fee.');
      const hash = hashTransaction(bytes);
      const pending = this.#pendingRecord('payment', hash, selected);
      const review = Object.freeze({
        id: String(++this.#sequence), kind: 'payment', network: this.network, address: recipient.address,
        amountBch: formatBch(amount), feeBch: formatBch(fee), feeSatoshis: fee.toString(),
        totalBch: formatBch(amount + fee), txid: hash, byteLength: bytes.length,
        expiresAt: Date.now() + REVIEW_MS, pending,
      });
      return { kind: 'payment', review, hex: binToHex(bytes), inputs: selected.map(utxo => ({ ...utxo, script: 'owner' })), category: null, pending };
    });
  }

  prepareTokenSend(proposal) {
    return this.#prepare(async () => {
      const parsed = tokenPayment.parse(proposal);
      this.#assertContractsAllowed();
      const policy = await resolveTokenPolicy(parsed.consensusPolicy,this.network,this.#client);
      if (!policy && parsed.nft && parsed.nft.commitment.length > 80) throw new WalletOperationError('commitment-policy','The default policy allows40bytes; explicit source-verified preview policy is required for longer commitments.');
      const recipient = validateTokenRecipient(parsed.address, this.network);
      const ownerOutputs = await this.#ownedOutputs();
      const available = ownerOutputs.filter(utxo => utxo.output.token && binToHex(utxo.output.token.category) === parsed.category);
      const selected = [];
      if (parsed.nft) {
        const nft = available.find(utxo => utxo.txid === parsed.nft.txid && utxo.index === parsed.nft.index);
        const actual = nft?.output.token.nft;
        if (!nft || !actual || actual.capability !== parsed.nft.capability || binToHex(actual.commitment) !== parsed.nft.commitment) throw new WalletOperationError('nft-mismatch', 'The selected unspent NFT does not match its category, owner, capability or commitment snapshot.');
        selected.push(nft);
      }
      const totals = { amount: sumSatoshis(selected.map(utxo => utxo.output.token.amount)) };
      for (const utxo of available.filter(utxo => !utxo.output.token.nft)) {
        if (totals.amount >= parsed.amount) break;
        if (selected.length >= 20) throw new WalletOperationError('too-many-token-inputs', 'At most 20 selected token inputs per payment.');
        selected.push(utxo); totals.amount += utxo.output.token.amount;
      }
      if (totals.amount < parsed.amount) throw new WalletOperationError('insufficient-tokens', 'Insufficient fungible tokens in the supported selected-address outputs. Unselected NFTs are never consumed.');
      const token = { category: hexToBin(parsed.category), amount: parsed.amount, ...(parsed.nft ? { nft: { capability: parsed.nft.capability, commitment: hexToBin(parsed.nft.commitment) } } : {}) };
      const output = { lockingBytecode: recipient.bytecode, valueSatoshis: 0n, token };
      output.valueSatoshis = getDustThreshold(output);
      const remainder = totals.amount - parsed.amount;
      const change = { lockingBytecode: this.#locking, valueSatoshis: 0n, token: { category: hexToBin(parsed.category), amount: remainder } };
      change.valueSatoshis = getDustThreshold(change);
      const built = await this.#build({ lead: selected.map(utxo => ({ utxo, script: 'owner', sequence: FINAL_SEQUENCE })), outputs: [output, ...(remainder > 0n ? [change] : [])], fundingPool: ownerOutputs.filter(utxo => !utxo.output.token), signingType: 0x61, consensusPolicy:policy });
      const tokenOutputs = built.transaction.outputs.filter(item => item.token);
      const nftOutputs = tokenOutputs.filter(item => item.token.nft);
      const nftMatches = !parsed.nft ? nftOutputs.length === 0 : nftOutputs.length === 1 && nftOutputs[0].token.nft.capability === parsed.nft.capability && binToHex(nftOutputs[0].token.nft.commitment) === parsed.nft.commitment;
      if (tokenOutputs.some(item => binToHex(item.token.category) !== parsed.category) || sumSatoshis(tokenOutputs.map(item => item.token.amount)) !== totals.amount || !nftMatches) throw new WalletOperationError('token-conservation', 'Token payment would mint, burn or change token identity.');
      if (built.fee > 100000n || built.fee > BigInt(built.bytes.length) * 100n) throw new WalletOperationError('fee-limit', 'Token payment fee exceeds policy.');
      const outputs = built.transaction.outputs.map((item, index) => {
        const decoded = lockingBytecodeToCashAddress({ bytecode: item.lockingBytecode, prefix: NETWORKS[this.network].prefix, tokenSupport: Boolean(item.token) });
        if (typeof decoded === 'string') throw new Error(decoded);
        const value = item.token;
        return Object.freeze({ index, role: index === 0 ? 'recipient' : value ? 'token-change' : 'bch-change', address: decoded.address, owned: binsAreEqual(item.lockingBytecode, this.#locking), valueSatoshis: item.valueSatoshis.toString(), amountBch: formatBch(item.valueSatoshis), token: value ? Object.freeze({ category: binToHex(value.category), amount: value.amount.toString(), nft: value.nft ? Object.freeze({ capability: value.nft.capability, commitment: binToHex(value.nft.commitment) }) : null }) : null });
      });
      const inputs = built.inputs.map(input => ({ ...input.utxo, script: 'owner' }));
      const pending = this.#pendingRecord('token-payment', built.hash, inputs, parsed.category, null, Date.now(), policy);
      const inputValue = sumSatoshis(inputs.map(input => input.valueSatoshis));
      const ownValue = sumSatoshis(built.transaction.outputs.filter(item => binsAreEqual(item.lockingBytecode, this.#locking)).map(item => item.valueSatoshis));
      const review = Object.freeze({ id: String(++this.#sequence), kind: 'token-payment', network: this.network, signingType: 'SIGHASH_ALL|FORKID|UTXOS', address: recipient.address, category: parsed.category, amount: parsed.amount.toString(), nft: parsed.nft ? Object.freeze({ ...parsed.nft }) : null, inputAmount: totals.amount.toString(), changeAmount: remainder.toString(), burnAmount: '0', outputs: Object.freeze(outputs), recipientBackingSatoshis: output.valueSatoshis.toString(), debitSatoshis: (inputValue - ownValue).toString(), feeSatoshis: built.fee.toString(), feeBch: formatBch(built.fee), txid: built.hash, byteLength: built.bytes.length, expiresAt: Date.now() + REVIEW_MS, pending, ...(policy ? {consensusPolicy:policy} : {}) });
      return { kind: 'token-payment', review, hex: binToHex(built.bytes), inputs, category: parsed.category, pending, consensusPolicy:policy };
    });
  }

  /** Sign only the exact BCH-only proposal reviewed here; never add change or inputs. */
  prepareTransaction(proposal) {
    return this.#prepare(async () => {
      const parsed = transactionProposal.parse(proposal);
      if (parsed.network !== this.network) throw new WalletOperationError('wrong-network', 'The proposal belongs to another network.');
      this.#assertContractsAllowed();
      const unsignedBytes = hexToBin(parsed.unsignedTransaction);
      const transaction = decodeTransaction(unsignedBytes);
      if (typeof transaction === 'string' || !binsAreEqual(encodeTransaction(transaction), unsignedBytes)) throw new WalletOperationError('invalid-transaction', 'The unsigned transaction must use canonical BCH encoding.');
      if (transaction.version !== 2 || transaction.locktime !== 0 || transaction.inputs.length < 1 || transaction.inputs.length > 100 || transaction.outputs.length < 1 || transaction.outputs.length > 50) throw new WalletOperationError('unsupported-transaction', 'Use version 2, locktime zero, 1–100 inputs and 1–50 outputs.');
      const ids = transaction.inputs.map(input => `${binToHex(input.outpointTransactionHash)}:${input.outpointIndex}`);
      if (new Set(ids).size !== ids.length) throw new WalletOperationError('duplicate-input', 'The proposal repeats an input.');
      if (transaction.inputs.some(input => input.unlockingBytecode.length !== 0 || input.sequenceNumber !== FINAL_SEQUENCE)) throw new WalletOperationError('unsupported-input', 'All inputs must be unsigned with final sequence numbers.');
      const outputs = transaction.outputs.map((output, index) => {
        if (output.token) throw new WalletOperationError('unsupported-token', 'General transaction proposals cannot move or create CashTokens.');
        const address = lockingBytecodeToCashAddress({ bytecode: output.lockingBytecode, prefix: NETWORKS[this.network].prefix });
        if (typeof address === 'string') throw new WalletOperationError('unsupported-output', 'Proposal outputs must be standard P2PKH, P2SH20 or P2SH32 addresses.');
        validateRecipient(address.address, this.network);
        if (output.valueSatoshis < getDustThreshold(output)) throw new WalletOperationError('dust', 'A proposal output is below its dust threshold.');
        return Object.freeze({ index, address: address.address, lockingBytecode: binToHex(output.lockingBytecode), valueSatoshis: output.valueSatoshis.toString(), amountBch: formatBch(output.valueSatoshis), owned: binsAreEqual(output.lockingBytecode, this.#locking) });
      });
      // Fetch source transactions ourselves. Never accept a dapp-supplied amount,
      // script, ownership claim or derivation path as authorization to sign.
      const available = new Map((await this.#utxos()).map(utxo => [outpointId(utxo), utxo]));
      const inputs = ids.map(id => {
        const input = available.get(id);
        if (!input) throw new WalletOperationError('unsupported-input', 'Every input must be an unspent BCH-only output of this session address.');
        return { ...input, script: 'owner' };
      });
      const sourceOutputs = inputs.map(input => input.output);
      const inValue = sumSatoshis(inputs.map(input => input.valueSatoshis));
      const outValue = sumSatoshis(transaction.outputs.map(output => output.valueSatoshis));
      const fee = inValue - outValue;
      if (fee <= 0n || fee > parsed.maxFeeSatoshis) throw new WalletOperationError('fee-limit', 'The proposal fee is non-positive or exceeds the approved maximum.');
      const estimatedSize = encodeTransaction({ ...transaction, inputs: transaction.inputs.map(input => ({ ...input, unlockingBytecode: new Uint8Array(P2PKH_UNLOCKING_BYTES) })) }).length;
      if (fee < BigInt(estimatedSize) || fee > BigInt(estimatedSize) * 100n) throw new WalletOperationError('fee-rate', 'Proposal fees must be between 1 and 100 satoshis per byte.');
      const keyBytes = this.#key.toBytes();
      try {
        transaction.inputs.forEach((input, index) => {
          const signature = this.#sign(transaction, sourceOutputs, index, this.#locking, keyBytes, SIGNING_TYPES[parsed.signingType]);
          input.unlockingBytecode = flattenBinArray([encodeDataPush(signature), encodeDataPush(this.#publicKey)]);
        });
      } finally { keyBytes.fill(0); }
      const unsignedAgain = encodeTransaction({ ...transaction, inputs: transaction.inputs.map(input => ({ ...input, unlockingBytecode: Uint8Array.of() })) });
      if (!binsAreEqual(unsignedAgain, unsignedBytes)) throw new WalletOperationError('proposal-changed', 'Signing changed the unsigned transaction.');
      verifyStandard(transaction, sourceOutputs);
      const bytes = encodeTransaction(transaction);
      const hash = hashTransaction(bytes);
      const pending = this.#pendingRecord('transaction', hash, inputs);
      const change = sumSatoshis(transaction.outputs.filter(output => binsAreEqual(output.lockingBytecode, this.#locking)).map(output => output.valueSatoshis));
      const review = Object.freeze({
        id: String(++this.#sequence), kind: 'transaction', network: this.network, txid: hash,
        byteLength: bytes.length, feeSatoshis: fee.toString(), feeBch: formatBch(fee),
        inputSatoshis: inValue.toString(), outputSatoshis: outValue.toString(),
        debitSatoshis: (inValue - change).toString(), outputs: Object.freeze(outputs),
        signingType: parsed.signingType, expiresAt: Date.now() + REVIEW_MS, pending,
      });
      return { kind: 'transaction', review, hex: binToHex(bytes), inputs, category: null, pending };
    });
  }

  #sign(transaction, sourceOutputs, inputIndex, coveredBytecode, keyBytes, signingType = SIGHASH_ALL_FORKID) {
    const serialization = generateSigningSerializationBch({ inputIndex, sourceOutputs, transaction }, { coveredBytecode, signingSerializationType: Uint8Array.of(signingType) });
    const signature = secp256k1.signMessageHashSchnorr(keyBytes, hash256(serialization));
    if (typeof signature === 'string') throw new Error('Transaction signing failed.');
    return flattenBinArray([signature, Uint8Array.of(signingType)]);
  }

  #unlocking(input, signature) {
    if (input.script === 'owner') return flattenBinArray([encodeDataPush(signature), encodeDataPush(this.#publicKey)]);
    return encodeFocusGardenUnlocking({ ...input.unlock, signature, redeemBytecode: input.redeem });
  }

  #transaction(inputs, outputs, placeholder) {
    return {
      version: 2, locktime: 0, outputs,
      inputs: inputs.map(input => ({
        outpointTransactionHash: hexToBin(input.utxo.txid), outpointIndex: input.utxo.index, sequenceNumber: input.sequence,
        unlockingBytecode: placeholder ? (input.script === 'owner' ? new Uint8Array(P2PKH_UNLOCKING_BYTES) : this.#unlocking(input, new Uint8Array(65))) : Uint8Array.of(),
      })),
    };
  }

  /**
   * Token-aware builder. `lead` inputs keep their positions (covenant baton at
   * index 0). Fee and change come only from BCH-only owner outputs; token
   * outputs are never selected. Exact size is measured with fixed-length
   * placeholder signatures, then every input is signed and VM-verified.
   */
  async #build({ lead, outputs, fundingPool, signingType = SIGHASH_ALL_FORKID, consensusPolicy }) {
    const used = new Set(lead.map(input => outpointId(input.utxo)));
    const fundingOutputs = fundingPool === undefined ? await this.#utxos() : fundingPool;
    const pool = fundingOutputs.filter(utxo => !used.has(outpointId(utxo))).sort((a, b) => (b.valueSatoshis > a.valueSatoshis ? 1 : b.valueSatoshis < a.valueSatoshis ? -1 : 0) || a.txid.localeCompare(b.txid) || a.index - b.index);
    const inputs = [...lead];
    const outValue = sumSatoshis(outputs.map(output => output.valueSatoshis));
    const change = { lockingBytecode: this.#locking, valueSatoshis: 0n };
    const sizeOf = list => BigInt(encodeTransaction(this.#transaction(inputs, list, true)).length);
    // A covenant baton's value is preserved exactly, so fees always need at least one owner input.
    const needsFunding = !lead.some(input => input.script === 'owner');
    let inValue = sumSatoshis(inputs.map(input => input.utxo.valueSatoshis));
    let size = sizeOf([...outputs, change]);
    while ((needsFunding && inputs.length === lead.length) || inValue < outValue + size) {
      const next = pool.shift();
      if (!next) throw new WalletOperationError('insufficient-funds', 'Insufficient BCH for this transaction and its network fee. Token outputs are never used as funding.', { shortfallSatoshis: (outValue + size - inValue).toString() });
      if (inputs.length - lead.length >= MAX_CONTRACT_FUNDING_INPUTS) throw new WalletOperationError('too-many-inputs', `Consolidate BCH first: at most ${MAX_CONTRACT_FUNDING_INPUTS} funding inputs.`);
      inputs.push({ utxo: next, script: 'owner', sequence: FINAL_SEQUENCE });
      inValue += next.valueSatoshis;
      size = sizeOf([...outputs, change]);
    }
    const changeValue = inValue - outValue - size;
    const finalOutputs = changeValue >= P2PKH_DUST ? [...outputs, { ...change, valueSatoshis: changeValue }] : outputs;
    for (const [index, output] of finalOutputs.entries()) {
      if (output.valueSatoshis < getDustThreshold(output)) throw new Error(`Output ${index} would be below the dust threshold.`);
    }
    const transaction = this.#transaction(inputs, finalOutputs, false);
    const sourceOutputs = inputs.map(input => input.utxo.output);
    if (consensusPolicy) assertTokenPolicyContext(transaction,inputs,this.#locking,encodeTransaction(transaction).length);
    const keyBytes = this.#key.toBytes();
    try {
      const signatures = inputs.map((input, index) => this.#sign(transaction, sourceOutputs, index, input.script === 'owner' ? this.#locking : input.redeem, keyBytes, signingType));
      inputs.forEach((input, index) => { transaction.inputs[index].unlockingBytecode = this.#unlocking(input, signatures[index]); });
    } finally { keyBytes.fill(0); }
    verifyStandard(transaction, sourceOutputs, consensusPolicy);
    const bytes = encodeTransaction(transaction);
    if (consensusPolicy && bytes.length > 10000) throw new WalletOperationError('consensus-policy-context','Preview subset size exceeds10000bytes.');
    const fee = inValue - sumSatoshis(finalOutputs.map(output => output.valueSatoshis));
    if (fee < BigInt(bytes.length) || fee > size + P2PKH_DUST - 1n) throw new Error('Unexpected transaction fee.');
    const funding = inputs.filter(input => input.script === 'owner');
    return { transaction, bytes, hash: hashTransaction(bytes), fee, inputs, funding, change: finalOutputs.length > outputs.length ? changeValue : 0n };
  }

  #draftFrom(kind, built, category, fields, publication = null) {
    const pending = this.#pendingRecord(kind, built.hash, built.inputs.map(input => input.utxo), category, publication);
    const review = Object.freeze({
      id: String(++this.#sequence), kind, network: this.network, ...fields,
      feeSatoshis: built.fee.toString(), feeBch: formatBch(built.fee),
      fundingInputs: built.funding.length, fundingSatoshis: sumSatoshis(built.funding.map(input => input.utxo.valueSatoshis)).toString(),
      changeSatoshis: built.change.toString(), txid: built.hash, byteLength: built.bytes.length,
      expiresAt: Date.now() + REVIEW_MS, pending,
    });
    return { kind, review, hex: binToHex(built.bytes), inputs: built.inputs.map(input => ({ ...input.utxo, script: input.script })), category, pending };
  }

  async #buildGenesis() {
    this.#assertContractsAllowed();
    const funding = await this.#utxos();
    const anchor = funding.filter(utxo => utxo.index === 0).sort((a, b) => (b.valueSatoshis > a.valueSatoshis ? 1 : b.valueSatoshis < a.valueSatoshis ? -1 : 0))[0];
    if (!anchor) throw new WalletOperationError('no-genesis-outpoint', 'A new garden needs a BCH output at index 0. Send a small amount to this wallet\'s own address first, then try again.');
    const category = anchor.txid;
    const covenant = this.#covenant(category);
    const built = await this.#build({
      lead: [{ utxo: anchor, script: 'owner', sequence: FINAL_SEQUENCE }],
      outputs: [{ lockingBytecode: covenant.locking, valueSatoshis: BATON_SATOSHIS, token: batonToken(category, GENESIS_STATE) }],
    });
    verifyCanonicalGenesis({ transaction: built.transaction, category, covenantLocking: covenant.locking });
    return this.#draftFrom('garden-genesis', built, category, { covenantAddress: covenant.address, gardenCategory: category, batonSatoshis: BATON_SATOSHIS.toString(), completed: 0 });
  }

  async #gardenBaton(category, { open }) {
    const { covenant, baton } = await this.#canonicalBaton(category);
    if (!baton) throw new WalletOperationError('garden-not-found', 'No canonical garden baton was found for this category.');
    if (baton.state.open !== open) throw new WalletOperationError(open ? 'garden-idle' : 'garden-open', open ? 'This garden has no open session.' : 'This garden already has an open session.');
    return { covenant, baton };
  }

  #covenantInput(baton, covenant, sequence, unlock) {
    return { utxo: baton, script: 'covenant', sequence, unlock, redeem: covenant.redeem };
  }

  async #buildOpen({ category, units, record } = {}) {
    this.#assertContractsAllowed();
    const id = parseCategory(category);
    checkUnits(units);
    if (typeof record !== 'string' || !/^[0-9a-fA-F]{64}$/.test(record)) throw new WalletOperationError('invalid-record', 'The record commitment must be 32 bytes of hex.');
    const recordBytes = hexToBin(record);
    const { covenant, baton } = await this.#gardenBaton(id, { open: false });
    const state = encodeGardenState({ open: true, completed: baton.state.completed, units, record: recordBytes });
    const built = await this.#build({
      lead: [this.#covenantInput(baton, covenant, FINAL_SEQUENCE, { fn: 'open', units, record: recordBytes })],
      outputs: [{ lockingBytecode: covenant.locking, valueSatoshis: baton.valueSatoshis, token: batonToken(id, state) }],
    });
    return this.#draftFrom('garden-open', built, id, { covenantAddress: covenant.address, gardenCategory: id, units, record: record.toLowerCase(), minimumWaitSeconds: units * UNIT_SECONDS, completed: baton.state.completed });
  }

  async #buildClose(kind, { category } = {}) {
    this.#assertContractsAllowed();
    const id = parseCategory(category);
    const { covenant, baton } = await this.#gardenBaton(id, { open: true });
    const { state } = baton;
    const complete = kind === 'garden-complete';
    let claimableAt = null;
    if (complete) {
      if (baton.height <= 0) throw new WalletOperationError('unconfirmed', 'The open session must confirm before its wait can be measured.');
      const timing = await this.#timing(baton);
      claimableAt = timing.claimableAt;
      // The node would reject an early spend as non-final; never offer one.
      if (!timing.claimable) throw new WalletOperationError('not-yet-claimable', 'The onchain minimum wait has not elapsed yet.', { claimableAt, mtp: timing.tip.mtp });
    }
    const completed = complete ? state.completed + 1 : state.completed;
    const outputs = [{ lockingBytecode: covenant.locking, valueSatoshis: baton.valueSatoshis, token: batonToken(id, encodeGardenState({ open: false, completed })) }];
    if (complete) outputs.push({ lockingBytecode: this.#locking, valueSatoshis: TREE_SATOSHIS, token: treeToken(id, encodeTreeCommitment({ index: state.completed, units: state.units, record: state.record })) });
    const built = await this.#build({
      lead: [this.#covenantInput(baton, covenant, complete ? relativeLockSequence(state.units) : FINAL_SEQUENCE, { fn: complete ? 'complete' : 'abandon' })],
      outputs,
    });
    return this.#draftFrom(kind, built, id, {
      covenantAddress: covenant.address, gardenCategory: id, units: state.units, record: binToHex(state.record), completed,
      ...(complete ? { treeSatoshis: TREE_SATOSHIS.toString(), treeIndex: state.completed, claimableAt } : {}),
    });
  }

  #planJournal(ciphertext) {
    const plan = planJournalPublication(ciphertext);
    return Object.freeze({ publicationId: plan.id, chunkCount: plan.chunks.length, totalBytes: plan.totalBytes, chunkBytes: Object.freeze(plan.chunks.map(chunk => chunk.length)), maxBytes: JOURNAL_MAX_BYTES, maxChunkBytes: JOURNAL_CHUNK_BYTES });
  }

  async #buildJournal({ ciphertext, chunkIndex } = {}) {
    this.#assertContractsAllowed();
    const plan = planJournalPublication(ciphertext);
    if (!Number.isInteger(chunkIndex) || chunkIndex < 0 || chunkIndex >= plan.chunks.length) throw new WalletOperationError('invalid-chunk', `Chunk index must be 0..${plan.chunks.length - 1}.`);
    const chunk = plan.chunks[chunkIndex];
    const output = encodeJournalOutput({ id: plan.id, index: chunkIndex, count: plan.chunks.length, chunk });
    const built = await this.#build({ lead: [], outputs: [output] });
    const publication = { id: plan.id, index: chunkIndex, count: plan.chunks.length };
    return this.#draftFrom('journal-chunk', built, null, {
      publicationId: plan.id, chunkIndex, chunkCount: plan.chunks.length, chunkBytes: chunk.length, totalBytes: plan.totalBytes,
      disclosure: 'Publishes these encrypted bytes permanently and publicly. Anyone can see their size, timing, and that this wallet published them. Only the app key can decrypt them; if that key is lost they are unreadable forever.',
    }, publication);
  }

  async #readJournal({ txids } = {}) {
    await this.#verifyNetwork();
    const hashes = z.array(txid).min(1).max(JOURNAL_MAX_CHUNKS).parse(txids);
    const parts = [];
    let authored = true;
    for (const hash of hashes) {
      const transaction = await this.#fetchTransaction(hash);
      const found = transaction.outputs.map(output => decodeJournalOutput(output.lockingBytecode)).filter(Boolean);
      if (found.length !== 1) throw new Error('Transaction does not contain exactly one journal chunk.');
      parts.push(found[0]);
      authored = authored && transaction.inputs.some(input => {
        const pushes = decodeAuthenticationInstructions(input.unlockingBytecode);
        const last = pushes[pushes.length - 1];
        return pushes.length === 2 && last?.data instanceof Uint8Array && binsAreEqual(last.data, this.#publicKey);
      });
    }
    const ordered = parts.slice().sort((a, b) => a.index - b.index);
    const { id, ciphertext } = assembleJournal(ordered);
    this.#assertOpen();
    return Object.freeze({ publicationId: id, chunkCount: ordered.length, ciphertext: binToHex(ciphertext), txids: Object.freeze(ordered.map(part => hashes[parts.indexOf(part)])), authoredByWallet: authored });
  }

  /** Raw (unverified) unspent sets for every script a pending record spends. */
  async #unspentIds(record) {
    const ids = new Set();
    const scripts = [this.#scriptHash, ...(record.category && GARDEN_KINDS.includes(record.kind) ? [this.#covenant(record.category).scriptHash] : [])];
    for (const scriptHash of scripts) for (const item of await this.#listUnspent(scriptHash)) ids.add(`${item.tx_hash.toLowerCase()}:${item.tx_pos}`);
    return ids;
  }

  async #inputsAllSpent(record) {
    const ids = await this.#unspentIds(record);
    return record.inputs.every(input => !ids.has(outpointId(input)));
  }

  #assertDraftActive(draft) {
    this.#assertOpen();
    if (this.#draft !== draft) throw new Error('This review was cancelled.');
    if (draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
  }

  async #checkDraftPolicy(draft) {
    if (!draft.consensusPolicy) return;
    if (draft.review.consensusPolicy !== draft.consensusPolicy || draft.pending.consensusPolicy !== draft.consensusPolicy) throw new WalletOperationError('consensus-policy-changed','Review/pending policy binding disagrees.');
    const transaction = decodeTransaction(hexToBin(draft.hex));
    assertTokenPolicyContext(transaction,draft.inputs.map(input=>({script:input.script,utxo:input})),this.#locking,draft.hex.length/2);
    const current = await resolveTokenPolicy(draft.consensusPolicy.id,this.network,this.#client);
    assertTokenPolicyContinuation(draft.consensusPolicy,current);
    const available = new Map((await this.#ownedOutputs()).map(output=>[outpointId(output),output]));
    if (draft.inputs.some(input=>!available.has(outpointId(input)) || available.get(outpointId(input)).coinbase || !binsAreEqual(available.get(outpointId(input)).output.lockingBytecode,this.#locking))) throw new WalletOperationError('input-spent','Preview-policy inputs changed while approval was pending.');
    this.#assertOpen();
    if (this.#draft !== draft) throw new Error('This review was cancelled.');
    if (draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
  }

  async #broadcast(id, options = {}, kinds = ['payment'], exportOnly = false) {
    this.#assertOpen();
    const draft = this.#draft;
    if (!draft || draft.review.id !== id || draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
    if (!kinds.includes(draft.kind)) throw new WalletOperationError('wrong-kind', 'Broadcast this review with its own API.');
    const persist = options?.persistPending;
    if (persist !== undefined && typeof persist !== 'function') throw new TypeError('persistPending must be a function.');
    if (draft.kind !== 'payment' && !persist) throw new WalletOperationError('persist-required', 'Persist the pending record before exporting or broadcasting this transaction.');
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    this.#busy = true;
    try {
      // Preflight: every covenant and funding input must still be unspent.
      const funding = draft.kind === 'token-payment' ? await this.#ownedOutputs() : await this.#utxos();
      const owned = new Map(funding.map(utxo => [outpointId(utxo), utxo]));
      const ownerOk = draft.inputs.filter(input => input.script === 'owner').every(input => owned.get(outpointId(input))?.valueSatoshis === input.valueSatoshis);
      let covenantOk = true;
      const covenantInputs = draft.inputs.filter(input => input.script === 'covenant');
      if (covenantInputs.length) {
        const { baton } = await this.#canonicalBaton(draft.category);
        covenantOk = covenantInputs.every(input => baton && outpointId(baton) === outpointId(input) && baton.valueSatoshis === input.valueSatoshis);
      }
      if (this.#draft !== draft) throw new Error('This review was cancelled.');
      if (!ownerOk || !covenantOk) throw new WalletOperationError('input-spent', 'An input was spent. Prepare the transaction again.');
      if (draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
      if (draft.consensusPolicy) { await this.#checkDraftPolicy(draft); this.#assertDraftActive(draft); }
      if (persist) {
        // Calling this API is the host's explicit approval boundary. Do not
        // expose signed bytes in preparation/review or before source preflight.
        if (draft.pending.txid !== draft.review.txid || hashTransaction(hexToBin(draft.hex)) !== draft.review.txid
          || draft.pending.kind !== draft.kind || draft.review.kind !== draft.kind
          || draft.pending.network !== this.network || draft.review.network !== this.network
          || draft.hex.length !== draft.review.byteLength * 2 || !/^(?:[0-9a-f]{2})+$/.test(draft.hex)) {
          throw new WalletOperationError('draft-mismatch', 'Signed transaction does not match the approved review and pending record.');
        }
        const signed = Object.freeze({ signedTransaction: draft.hex, txid: draft.pending.txid, network: draft.pending.network, kind: draft.pending.kind, ...(draft.consensusPolicy ? {consensusPolicy:draft.consensusPolicy} : {}) });
        try { await persist(draft.pending, signed); }
        catch (cause) { throw Object.assign(new WalletOperationError('persist-failed', 'The pending record could not be saved, so nothing was broadcast.'), { cause }); }
        // Explicit policy raw is now durably owned by the host. Retain the
        // original reservation even if a subsequent source/consent check fails.
        if (draft.consensusPolicy) this.#pending = draft.pending;
        this.#assertOpen();
        if (this.#draft !== draft) throw new Error('This review was cancelled.');
        if (draft.review.expiresAt < Date.now()) throw new Error('Review expired. Prepare it again.');
      }
      if (draft.consensusPolicy) { await this.#checkDraftPolicy(draft); this.#assertDraftActive(draft); }
      this.#draft = undefined; // consume before submitting; double taps cannot resend
      this.#pending = draft.pending;
      if (draft.kind === 'garden-genesis') this.#lastCategory = draft.category;
      // Export is an authorization to relay elsewhere. Reserve the inputs just
      // like a submitted transaction, even if delivery to the requester fails.
      if (exportOnly) return Object.freeze({ txid: draft.review.txid, network: this.network, kind: 'transaction', signedTransaction: draft.hex, pending: draft.pending });
      try {
        const hash = new TransactionHash(await this.#client.request('blockchain.transaction.broadcast', [draft.hex])).toHex();
        if (hash !== draft.review.txid) throw new Error('Electrum returned an unexpected transaction hash.');
        return { txid: hash, network: this.network, kind: draft.kind };
      } catch (cause) { throw new BroadcastUncertainError(draft.review.txid, cause); }
    } catch (error) {
      if (draft.consensusPolicy && this.#pending === draft.pending && this.#draft === draft) this.#draft = undefined;
      throw error;
    } finally { this.#busy = false; }
  }

  broadcast(id, options) { return this.#broadcast(id, options, ['payment', 'transaction', 'token-payment']); }

  exportSignedTransaction(id, options) { return this.#broadcast(id, options, ['transaction'], true); }

  cancelSend() { this.#generation++; this.#draft = undefined; }

  /** The submitted-but-unresolved transaction, or null. Persist it before broadcast. */
  get pending() { return this.#pending ?? null; }

  /** After restart: block new transactions until the persisted record is resolved. */
  restorePending(record) {
    this.#assertOpen();
    const parsed = pendingRecord.parse(record);
    if (parsed.consensusPolicy && (parsed.kind !== 'token-payment' || parsed.network !== 'chipnet')) throw new WalletOperationError('consensus-policy-context','Policy metadata is only valid for Chipnet token-payment pending records.');
    if (this.#pending?.txid === parsed.txid && JSON.stringify(this.#pending.consensusPolicy) !== JSON.stringify(parsed.consensusPolicy)) throw new WalletOperationError('consensus-policy-changed','Cannot replace the original pending policy binding.');
    if (parsed.network !== this.network) throw new WalletOperationError('wrong-network', 'This pending record belongs to another network.');
    const recordPath = parsed.path ?? `m/44'/${NETWORKS[this.network].coinType}'/0'/0/0`;
    if (recordPath !== this.path) throw new WalletOperationError('wrong-path', 'Restore this pending record in its original HD address session.');
    if (parsed.address !== undefined && parsed.address !== this.address) throw new WalletOperationError('wrong-wallet', 'This pending record belongs to another wallet address.');
    if (this.#pending && this.#pending.txid !== parsed.txid) throw new WalletOperationError('pending', 'Another pending transaction is already being resolved.');
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    this.cancelSend();
    this.#pending = this.#pendingRecord(parsed.kind, parsed.txid, parsed.inputs, parsed.category, parsed.publication, parsed.createdAt, parsed.consensusPolicy ? freezeTokenPolicy(parsed.consensusPolicy) : null);
    if (parsed.kind === 'garden-genesis') this.#lastCategory = parsed.category;
    return this.#pending;
  }

  async #findPending(record) {
    const history = historyList.parse(await this.#client.request('blockchain.scripthash.get_history', [this.#scriptHash]));
    const entry = history.find(item => item.tx_hash === record.txid);
    if (!entry) return undefined;
    const transaction = await this.#fetchTransaction(record.txid);
    const spent = new Set(transaction.inputs.map(input => `${binToHex(input.outpointTransactionHash)}:${input.outpointIndex}`));
    if (spent.size !== record.inputs.length || !record.inputs.every(input => spent.has(outpointId(input)))) throw new Error('Pending transaction inputs do not match the record.');
    return { status: entry.height > 0 ? 'confirmed' : 'mempool', height: entry.height > 0 ? entry.height : 0 };
  }

  /**
   * Resolve the pending record without broadcasting anything:
   * confirmed/mempool (seen; unblocks), conflicted (inputs spent elsewhere;
   * unblocks), unknown (not seen and inputs unspent; stays blocked).
   */
  async checkPending() {
    await this.#verifyNetwork();
    const record = this.#pending;
    if (!record) return null;
    if (this.#busy) throw new WalletOperationError('busy', 'A wallet operation is already running.');
    this.#busy = true;
    try {
      let found = await this.#findPending(record);
      let status;
      if (found) status = found.status;
      else if (await this.#inputsAllUnspent(record)) status = 'unknown';
      else {
        found = await this.#findPending(record); // it may have arrived meanwhile
        status = found ? found.status : 'conflicted';
      }
      this.#assertOpen();
      if (status !== 'unknown' && this.#pending === record) this.#pending = undefined;
      return Object.freeze({ txid: record.txid, kind: record.kind, status, height: found?.height ?? 0, resolved: status !== 'unknown' });
    } finally { this.#busy = false; }
  }

  async #inputsAllUnspent(record) {
    const ids = await this.#unspentIds(record);
    return record.inputs.every(input => ids.has(outpointId(input)));
  }

  /**
   * Explicit user decision only: forget a pending record that the server has
   * never seen while all its inputs remain unspent. If the old transaction was
   * actually relayed it can still confirm; a new transaction spending the same
   * inputs would then fail rather than double-spend.
   */
  async discardPending(hash) {
    const record = this.#pending;
    if (!record || record.txid !== txid.parse(hash)) throw new WalletOperationError('no-pending', 'There is no such pending transaction.');
    const result = await this.checkPending();
    if (result.status === 'unknown' && this.#pending === record) this.#pending = undefined;
    return Object.freeze({ ...result, discarded: result.status === 'unknown' });
  }

  async lookupTransaction(hash) {
    await this.#verifyNetwork();
    const value = new TransactionHash(hash).toHex();
    const raw = hex.parse(await this.#client.request('blockchain.transaction.get', [value, false]));
    if (hashTransaction(hexToBin(raw)) !== value) throw new Error('Transaction lookup returned the wrong hash.');
    return { txid: value, found: true };
  }

  close() { this.#closed = true; this.#generation++; this.#draft = undefined; this.#key.destroy(); this.#client.close(); }
}
