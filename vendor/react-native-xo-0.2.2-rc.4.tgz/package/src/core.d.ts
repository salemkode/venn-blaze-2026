import type {FocusGardenArtifact} from './focus-garden/index.js';

export type Network = 'chipnet' | 'mainnet';
export interface ElectrumTransport {
  request(method: string, params?: unknown[]): Promise<unknown>;
  close(): void;
}
export interface WalletOptions {
  mnemonic: string;
  network?: Network;
  endpoint?: string;
  client?: ElectrumTransport;
  /** Garden, journal, token payments and general transaction proposals are refused on Mainnet unless this is true. */
  allowMainnetContracts?: boolean;
  /** Select one BIP44 address. Defaults preserve the original account-zero address. No automatic discovery. */
  hd?: {account?: number; change?: 0 | 1 | 7; index?: number};
}

export type TransactionKind = 'payment' | 'garden-genesis' | 'garden-open' | 'garden-complete' | 'garden-abandon' | 'journal-chunk' | 'transaction' | 'token-payment';

/** Explicit final-P2PKH source-backed subset, not a generic VM2027 verifier. */
export interface TokenConsensusPolicy {
  readonly id: 'chipnet-preview2027-final-p2pkh-v1';
  readonly network: 'chipnet';
  readonly sourceCommit: '3e6827e95c7a17497e09ac15556debd116dea1d0';
  readonly vm: 'BCH_2026_05-final-p2pkh-subset';
  readonly trust: 'electrum-not-spv';
  readonly anchors: readonly [Readonly<{height: 115252; hash: string}>, Readonly<{height: 284827; hash: string}>];
  readonly tipHeight: number;
  readonly tipHash: string;
  readonly medianTimePast: number;
  readonly maximumCommitmentBytes: 128;
}

/** JSON-safe record the host must persist (encrypted) BEFORE broadcast completes. */
export interface PendingRecord {
  readonly version: 1;
  /** Present ONLY for explicitly selected preview token policy; absent legacy/default means40bytes. */
  readonly consensusPolicy?: TokenConsensusPolicy;
  readonly network: Network;
  /** Present in new records; absent legacy records belong to account 0 / external 0. */
  readonly path?: string;
  /** New records bind the originating wallet address. Legacy records require host wallet-identity namespacing. */
  readonly address?: string;
  readonly kind: TransactionKind;
  readonly txid: string;
  readonly category: string | null;
  readonly inputs: ReadonlyArray<{readonly txid: string; readonly index: number}>;
  readonly createdAt: number;
  readonly publication: {readonly id: string; readonly index: number; readonly count: number} | null;
}
export interface PendingStatus {
  readonly txid: string;
  readonly kind: TransactionKind;
  /** confirmed/mempool: seen. conflicted: inputs spent elsewhere. unknown: not seen, inputs unspent (still blocked). */
  readonly status: 'confirmed' | 'mempool' | 'conflicted' | 'unknown';
  readonly height: number;
  readonly resolved: boolean;
}
export interface BroadcastOptions {
  /** Approval-boundary callback, after source preflight and before submission/export.
   * Await durable host storage of BOTH pending and exact signed bytes; a throw,
   * cancellation, closure or expiry prevents submission. Required for non-payment
   * kinds. One-argument callbacks remain supported; durability/fsync is host-owned.
   */
  persistPending?: (record: PendingRecord, transaction: Readonly<Pick<PendingRecord, 'txid' | 'network' | 'kind' | 'consensusPolicy'> & {signedTransaction: string}>) => Promise<void> | void;
}
export interface BroadcastResult { txid: string; network: Network; kind: TransactionKind }

interface ReviewBase {
  readonly id: string;
  readonly kind: TransactionKind;
  readonly network: Network;
  readonly feeSatoshis: string;
  readonly feeBch: string;
  readonly txid: string;
  readonly byteLength: number;
  readonly expiresAt: number;
  readonly pending: PendingRecord;
}
export interface PaymentReview extends ReviewBase {
  readonly kind: 'payment';
  readonly address: string;
  readonly amountBch: string;
  readonly totalBch: string;
}
/** Versioned, JSON-safe BCH-only proposal. This is not a WalletConnect wire format. */
export interface TransactionProposal {
  version: 1;
  network: Network;
  /** Canonically encoded BCH transaction, empty unlocking scripts, final sequences, version 2 and locktime 0. */
  unsignedTransaction: string;
  /** Positive integer string, <= 100000 sats. Also bounded to 1–100 sat/B. */
  maxFeeSatoshis: string;
  /** Defaults to the original 0x41 mode. WizardConnect requires the explicit 0x61 mode. */
  signingType?: 'SIGHASH_ALL|FORKID' | 'SIGHASH_ALL|FORKID|UTXOS';
}
export interface TransactionReview extends ReviewBase {
  readonly kind: 'transaction';
  readonly signingType: 'SIGHASH_ALL|FORKID' | 'SIGHASH_ALL|FORKID|UTXOS';
  readonly inputSatoshis: string;
  readonly outputSatoshis: string;
  /** Inputs minus outputs returning to this session address; includes fee. */
  readonly debitSatoshis: string;
  readonly outputs: ReadonlyArray<Readonly<{index: number; address: string; lockingBytecode: string; valueSatoshis: string; amountBch: string; owned: boolean}>>;
}
export interface SignedTransactionExport {
  readonly txid: string;
  readonly network: Network;
  readonly kind: 'transaction';
  readonly signedTransaction: string;
  readonly pending: PendingRecord;
}
export interface MessageReview {
  readonly kind: 'message';
  readonly id: string;
  readonly network: Network;
  readonly address: string;
  readonly publicKey: string;
  readonly peer: string;
  readonly message: string;
  readonly byteLength: number;
  readonly expiresAt: number;
}
export interface MessageSignature {
  readonly kind: 'message';
  readonly network: Network;
  readonly address: string;
  readonly publicKey: string;
  readonly peer: string;
  readonly message: string;
  readonly signature: string;
  readonly encoding: 'base64';
  readonly algorithm: 'bitcoin-signed-message';
}
export interface NftSelection {
  txid: string;
  index: number;
  capability: 'none' | 'mutable' | 'minting';
  commitment: string;
}
export interface TokenInventory {
  readonly consensusPolicy?: TokenConsensusPolicy;
  readonly network: Network;
  readonly path: string;
  readonly address: string;
  readonly categories: ReadonlyArray<Readonly<{
    category: string;
    amount: string;
    backingSatoshis: string;
    outputCount: number;
    nfts: ReadonlyArray<Readonly<NftSelection & {amount: string; valueSatoshis: string; commitmentSupported: boolean}>>;
  }>>;
}
export interface TokenPaymentReview extends ReviewBase {
  readonly consensusPolicy?: TokenConsensusPolicy;
  readonly kind: 'token-payment';
  readonly signingType: 'SIGHASH_ALL|FORKID|UTXOS';
  readonly address: string;
  readonly category: string;
  readonly amount: string;
  readonly nft: Readonly<NftSelection> | null;
  readonly inputAmount: string;
  readonly changeAmount: string;
  readonly burnAmount: '0';
  readonly recipientBackingSatoshis: string;
  readonly debitSatoshis: string;
  readonly outputs: ReadonlyArray<Readonly<{
    index: number; role: 'recipient' | 'token-change' | 'bch-change'; address: string;
    owned: boolean; valueSatoshis: string; amountBch: string;
    token: Readonly<{category: string; amount: string; nft: Readonly<Pick<NftSelection, 'capability' | 'commitment'>> | null}> | null;
  }>>;
}
interface FundedReview extends ReviewBase {
  readonly fundingInputs: number;
  readonly fundingSatoshis: string;
  readonly changeSatoshis: string;
}
export interface FocusGardenReview extends FundedReview {
  readonly kind: 'garden-genesis' | 'garden-open' | 'garden-complete' | 'garden-abandon';
  readonly covenantAddress: string;
  readonly gardenCategory: string;
  /** Completed count after this transaction. */
  readonly completed: number;
  readonly batonSatoshis?: string;
  readonly units?: number;
  readonly record?: string;
  readonly minimumWaitSeconds?: number;
  readonly treeSatoshis?: string;
  readonly treeIndex?: number;
  /** Informational MTP seconds. */
  readonly claimableAt?: number | null;
}
export interface JournalChunkReview extends FundedReview {
  readonly kind: 'journal-chunk';
  readonly publicationId: string;
  readonly chunkIndex: number;
  readonly chunkCount: number;
  readonly chunkBytes: number;
  readonly totalBytes: number;
  readonly disclosure: string;
}

export interface GardenState {
  readonly open: boolean;
  readonly completed: number;
  readonly units: number;
  readonly record: string | null;
  readonly minimumWaitSeconds: number;
}
export interface Garden {
  readonly network: Network;
  readonly category: string;
  readonly covenantAddress: string;
  readonly genesisTxid: string;
  readonly outpoint: {readonly txid: string; readonly index: number};
  readonly valueSatoshis: string;
  readonly state: GardenState;
  /** 0 while unconfirmed. */
  readonly height: number;
  readonly confirmations: number;
  readonly tipHeight: number;
  /** Tip median-time-past, seconds. */
  readonly mtp: number;
  readonly claimableAt: number | null;
  readonly claimable: boolean;
}
export interface FocusGardenApi {
  readonly artifact: FocusGardenArtifact;
  covenantAddress(category: string): string;
  /** Without a category: the garden created by this session's genesis, else null. */
  readGarden(category?: string): Promise<Garden | null>;
  prepareGenesis(): Promise<FocusGardenReview>;
  prepareOpen(options: {category: string; units: number; record: string}): Promise<FocusGardenReview>;
  prepareComplete(options: {category: string}): Promise<FocusGardenReview>;
  prepareAbandon(options: {category: string}): Promise<FocusGardenReview>;
  broadcast(reviewId: string, options: BroadcastOptions): Promise<BroadcastResult>;
  cancel(): void;
}
export interface JournalApi {
  plan(ciphertext: string | Uint8Array): Readonly<{publicationId: string; chunkCount: number; totalBytes: number; chunkBytes: readonly number[]; maxBytes: number; maxChunkBytes: number}>;
  preparePublish(options: {ciphertext: string | Uint8Array; chunkIndex: number}): Promise<JournalChunkReview>;
  broadcast(reviewId: string, options: BroadcastOptions): Promise<BroadcastResult>;
  cancel(): void;
  read(options: {txids: string[]}): Promise<Readonly<{publicationId: string; chunkCount: number; ciphertext: string; txids: readonly string[]; authoredByWallet: boolean}>>;
}

export interface WalletSession {
  readonly network: Network;
  readonly path: string;
  readonly address: string;
  readonly tokenAddress: string;
  /** Compressed secp256k1 public key, hex. Never private material. */
  readonly publicKey: string;
  readonly focusGarden: FocusGardenApi;
  readonly journal: JournalApi;
  readonly pending: PendingRecord | null;
  /** Public children of the selected account. Does not select, scan, or spend those addresses. */
  deriveAddress(options?: {change?: 0 | 1 | 7; index?: number}): Readonly<{network: Network; path: string; address: string; publicKey: string; lockingBytecode: string}>;
  /** Explicit host privacy/peer approval required. Returns public BIP32 xpub (Mainnet) or tpub (Chipnet) only. */
  exportXpub(options: {scope: 'account' | 'receive' | 'change' | 'defi'; acknowledgePrivacy: true}): Readonly<{scope: 'account' | 'receive' | 'change' | 'defi'; network: Network; path: string; xpub: string}>;
  refresh(): Promise<Readonly<{address: string; network: Network; balanceSatoshis: string; balanceBch: string; outputCount: number}>>;
  /** Source-verified token inventory. Metadata, issuer authority and full address discovery are not provided. */
  refreshTokens(options?: {consensusPolicy?: TokenConsensusPolicy['id']}): Promise<TokenInventory>;
  prepareSend(payment: {address: string; amountBch: string}): Promise<PaymentReview>;
  /** Bounded FT payment / one selected NFT transfer. No mint/burn/mutation/covenant/foreign inputs. */
  prepareTokenSend(payment: {address: string; category: string; amount: string; nft?: NftSelection; consensusPolicy?: TokenConsensusPolicy['id']}): Promise<TokenPaymentReview>;
  /** All inputs must belong to this session; no tokens/covenant-input or partial signing. Mainnet requires opt-in. */
  prepareTransaction(proposal: TransactionProposal): Promise<TransactionReview>;
  /** Review exact UTF-8 text (<=4096 bytes), peer and selected address. No signature is released. */
  prepareMessage(proposal: {peer: string; message: string}): Promise<MessageReview>;
  /** Explicit human approval boundary. Standard compact recoverable ECDSA/Base64, consumed once. Never broadcasts. */
  exportMessageSignature(id: string, options: {peer: string}): MessageSignature;
  /** User approval boundary: persists, consumes review and blocks inputs before releasing relayable bytes. Never broadcasts. */
  exportSignedTransaction(id: string, options: BroadcastOptions & Required<Pick<BroadcastOptions, 'persistPending'>>): Promise<SignedTransactionExport>;
  /** Cancels the single shared review (payment, transaction, garden or journal). */
  cancelSend(): void;
  broadcast(id: string, options?: BroadcastOptions): Promise<BroadcastResult>;
  restorePending(record: PendingRecord): PendingRecord;
  checkPending(): Promise<PendingStatus | null>;
  discardPending(txid: string): Promise<PendingStatus & {readonly discarded: boolean}>;
  lookupTransaction(txid: string): Promise<{txid: string; found: boolean}>;
  close(): void;
}
export declare const NETWORKS: Readonly<Record<Network, Readonly<{label: string; prefix: string; coinType: number; endpoint: string; checkpointHeight: number; checkpointHash: string; checkpointSource?: string; explorer: string}>>>;
export declare function createWalletSession(options: WalletOptions): WalletSession;
export declare function formatBch(satoshis: bigint | number | string): string;
export declare function parseBch(amountBch: string): bigint;
export declare function validateRecipient(address: string, network: Network): {address: string; bytecode: Uint8Array};
export declare function validateTokenRecipient(address: string, network: Network): {address: string; bytecode: Uint8Array};
export declare class BroadcastUncertainError extends Error { readonly txid: string; }
export declare class WalletOperationError extends Error {
  readonly code: string;
  readonly details?: Readonly<Record<string, unknown>>;
}
