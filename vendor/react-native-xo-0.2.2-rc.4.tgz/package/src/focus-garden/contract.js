// Pure FocusGarden covenant helpers: exact constructor compilation, P2SH32
// address, unlocking bytecode, and canonical-genesis rules. No keys, no network.
import {
  bigIntToVmNumber, binToHex, binsAreEqual, encodeDataPush, encodeLockingBytecodeP2sh32,
  flattenBinArray, hash256, hexToBin, lockingBytecodeToCashAddress,
} from '@bitauth/libauth';
import { WalletOperationError } from '../errors.js';
import { FOCUS_GARDEN_ARTIFACT } from './artifact.js';
import { GENESIS_STATE, checkUnits, decodeGardenState } from './protocol.js';

/** Value kept on the baton forever (the covenant forbids changing it); above token-output dust. */
export const BATON_SATOSHIS = 1000n;
/** Value of each minted tree NFT sent to the owner; above token-output dust. */
export const TREE_SATOSHIS = 1000n;
export const FUNCTION_INDEX = Object.freeze({ open: 0, complete: 1, abandon: 2 });
const contractBytecode = hexToBin(FOCUS_GARDEN_ARTIFACT.bytecodeHex);

/** Category ids use explorer/txid (display) byte order, as lowercase hex. */
export function parseCategory(category) {
  if (typeof category !== 'string' || !/^[0-9a-fA-F]{64}$/.test(category)) throw new WalletOperationError('invalid-category', 'A garden category is a 64-character transaction id.');
  return category.toLowerCase();
}

function parsePublicKey(publicKey) {
  const bytes = typeof publicKey === 'string' ? hexToBin(publicKey) : publicKey;
  if (!(bytes instanceof Uint8Array) || bytes.length !== 33 || (bytes[0] !== 2 && bytes[0] !== 3)) throw new TypeError('Owner public key must be 33-byte compressed secp256k1.');
  return bytes;
}

/**
 * CashScript constructor compilation: arguments are pushed in reverse order
 * before the artifact bytecode. `gardenCategory` is the wire (reversed) order
 * returned by OP_UTXOTOKENCATEGORY.
 */
export function focusGardenRedeemBytecode({ ownerPublicKey, category }) {
  const wire = hexToBin(parseCategory(category)).reverse();
  return flattenBinArray([encodeDataPush(wire), encodeDataPush(parsePublicKey(ownerPublicKey)), contractBytecode]);
}

export function focusGardenLockingBytecode(parameters) {
  return encodeLockingBytecodeP2sh32(hash256(focusGardenRedeemBytecode(parameters)));
}

/** Token-aware P2SH32 CashAddress of one owner's garden covenant. */
export function focusGardenAddress({ ownerPublicKey, category, prefix }) {
  const result = lockingBytecodeToCashAddress({ bytecode: focusGardenLockingBytecode({ ownerPublicKey, category }), prefix, tokenSupport: true });
  if (typeof result === 'string') throw new Error(result);
  return result.address;
}

/** Unlocking bytecode for one ABI function: args reversed, selector, redeem script. */
export function encodeFocusGardenUnlocking({ fn, signature, units, record, redeemBytecode }) {
  if (!(fn in FUNCTION_INDEX)) throw new TypeError('Unknown FocusGarden function.');
  const args = fn === 'open' ? [signature, bigIntToVmNumber(BigInt(checkUnits(units))), record] : [signature];
  if (fn === 'open' && (!(record instanceof Uint8Array) || record.length !== 32)) throw new TypeError('Record commitment must be 32 bytes.');
  return flattenBinArray([
    ...args.slice().reverse().map(item => encodeDataPush(item)),
    encodeDataPush(bigIntToVmNumber(BigInt(FUNCTION_INDEX[fn]))),
    encodeDataPush(redeemBytecode),
  ]);
}

export function batonToken(category, commitment) {
  return { amount: 0n, category: hexToBin(parseCategory(category)), nft: { capability: 'minting', commitment } };
}
export function treeToken(category, commitment) {
  return { amount: 0n, category: hexToBin(parseCategory(category)), nft: { capability: 'none', commitment } };
}

export function hasCategory(output, category) {
  return Boolean(output.token) && binToHex(output.token.category) === category;
}

/**
 * Returns the decoded state if `output` is a well-formed baton of `category`
 * at the covenant, otherwise undefined. Never accepts fungible amounts,
 * non-minting capabilities, foreign scripts, or malformed commitments.
 */
export function readBatonOutput(output, category, covenantLocking) {
  if (!hasCategory(output, category) || !binsAreEqual(output.lockingBytecode, covenantLocking)) return undefined;
  const { token } = output;
  if (token.amount !== 0n || token.nft?.capability !== 'minting') return undefined;
  try { return decodeGardenState(token.nft.commitment); } catch { return undefined; }
}

/**
 * Verifier rule: the category's genesis transaction (the one spending
 * `category:0` as input 0) must create exactly one output of that category: a
 * minting NFT locked to FocusGarden(owner, category) holding GENESIS_STATE.
 * Otherwise another minting token could exist and forge trees.
 */
export function verifyCanonicalGenesis({ transaction, category, covenantLocking }) {
  const id = parseCategory(category);
  const [first] = transaction.inputs;
  if (!first || binToHex(first.outpointTransactionHash) !== id || first.outpointIndex !== 0) throw new WalletOperationError('not-canonical', 'This transaction is not the garden category genesis.');
  const created = transaction.outputs.filter(output => output.token && binToHex(output.token.category) === id);
  if (created.length !== 1) throw new WalletOperationError('not-canonical', 'Garden genesis created more than one token output; trees of this category cannot be trusted.');
  const [baton] = created;
  if (!binsAreEqual(baton.lockingBytecode, covenantLocking) || baton.token.amount !== 0n || baton.token.nft?.capability !== 'minting' || !binsAreEqual(baton.token.nft.commitment, GENESIS_STATE)) {
    throw new WalletOperationError('not-canonical', 'Garden genesis did not lock one fresh minting baton to this owner\'s covenant.');
  }
  return true;
}
