// Network-free FocusGarden protocol helpers. Wallet operations live on
// `session.focusGarden` (see core.js); these exports never touch keys.
export { FOCUS_GARDEN_ARTIFACT } from './artifact.js';
export {
  BATON_SATOSHIS, TREE_SATOSHIS, FUNCTION_INDEX, batonToken, treeToken, encodeFocusGardenUnlocking,
  focusGardenAddress, focusGardenLockingBytecode, focusGardenRedeemBytecode, parseCategory,
  readBatonOutput, verifyCanonicalGenesis,
} from './contract.js';
export {
  BIP68_DISABLE_FLAG, BIP68_TIME_FLAG, GENESIS_STATE, MAX_UNITS, MIN_UNITS, STATE_BYTES, TREE_BYTES, UNIT_SECONDS,
  decodeGardenState, decodeTreeCommitment, encodeGardenState, encodeTreeCommitment, minimumWaitSeconds,
  relativeLockSequence, unitsForDurationSeconds,
} from './protocol.js';
