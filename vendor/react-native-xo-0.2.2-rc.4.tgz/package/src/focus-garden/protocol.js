// Byte layouts and timing rules for contracts/FocusGarden.cash.
//
// Provenance: same layout as the Focus Garden app's contracts/focus/protocol.js
// (sha256 1b1ed3bd…242a, see contracts/PROVENANCE.md). Kept inside this package
// so it never imports application files. Pure data helpers: no keys or network.

export const UNIT_SECONDS = 512; // BIP68 time-based granularity
export const BIP68_TIME_FLAG = 1 << 22;
export const BIP68_DISABLE_FLAG = 2 ** 31;
export const MIN_UNITS = 1;
export const MAX_UNITS = 1024;
export const STATE_BYTES = 40;
export const TREE_BYTES = 39;
const VERSION = 0x01;

/** Round a planned duration up to whole 512-second units (never shorter). */
export function unitsForDurationSeconds(seconds) {
  if (!Number.isInteger(seconds) || seconds <= 0) throw new RangeError('Duration must be a positive whole number of seconds.');
  const units = Math.ceil(seconds / UNIT_SECONDS);
  if (units > MAX_UNITS) throw new RangeError('Duration exceeds the covenant maximum.');
  return units;
}

export function minimumWaitSeconds(units) { return checkUnits(units) * UNIT_SECONDS; }

/** nSequence for the baton input of a `complete` transaction. */
export function relativeLockSequence(units) { return (BIP68_TIME_FLAG | checkUnits(units)) >>> 0; }

export function checkUnits(units) {
  if (!Number.isInteger(units) || units < MIN_UNITS || units > MAX_UNITS) throw new RangeError(`Units must be ${MIN_UNITS}..${MAX_UNITS}.`);
  return units;
}

function uintLE(value, bytes) {
  const out = new Uint8Array(bytes);
  let rest = value;
  for (let i = 0; i < bytes; i++) { out[i] = rest & 0xff; rest = Math.floor(rest / 256); }
  return out;
}
function readUintLE(bytes) { return bytes.reduceRight((sum, byte) => sum * 256 + byte, 0); }
function record32(record) {
  if (!(record instanceof Uint8Array) || record.length !== 32) throw new TypeError('Record commitment must be 32 bytes.');
  return record;
}
function checkCount(count) {
  if (!Number.isInteger(count) || count < 0 || count >= 0x7fffffff) throw new RangeError('Completed count is out of range.');
  return count;
}

export function encodeGardenState({ open, completed, units = 0, record }) {
  const out = new Uint8Array(STATE_BYTES);
  out[0] = VERSION;
  out[1] = open ? 1 : 0;
  out.set(uintLE(checkCount(completed), 4), 2);
  if (open) { out.set(uintLE(checkUnits(units), 2), 6); out.set(record32(record), 8); }
  return out;
}

export const GENESIS_STATE = encodeGardenState({ open: false, completed: 0 });

/** Strict: idle states must carry zero units/record, open states valid units. */
export function decodeGardenState(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length !== STATE_BYTES || bytes[0] !== VERSION) throw new TypeError('Not a FocusGarden state commitment.');
  if (bytes[1] > 1) throw new TypeError('Unknown FocusGarden state.');
  return { open: bytes[1] === 1, completed: readUintLE(bytes.slice(2, 6)), units: readUintLE(bytes.slice(6, 8)), record: bytes.slice(8) };
}

export function encodeTreeCommitment({ index, units, record }) {
  const out = new Uint8Array(TREE_BYTES);
  out[0] = VERSION;
  out.set(uintLE(checkCount(index), 4), 1);
  out.set(uintLE(checkUnits(units), 2), 5);
  out.set(record32(record), 7);
  return out;
}

export function decodeTreeCommitment(bytes) {
  if (!(bytes instanceof Uint8Array) || bytes.length !== TREE_BYTES || bytes[0] !== VERSION) throw new TypeError('Not a FocusGarden tree commitment.');
  const units = readUintLE(bytes.slice(5, 7));
  return { index: readUintLE(bytes.slice(1, 5)), units, minimumWaitSeconds: units * UNIT_SECONDS, record: bytes.slice(7) };
}
