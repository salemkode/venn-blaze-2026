export interface FocusGardenArtifact {
  readonly contractName: 'FocusGarden';
  readonly compiler: {readonly name: 'cashc'; readonly version: string};
  readonly fingerprint: string;
  readonly artifactSha256: string;
  readonly sourceSha256: string;
  readonly constructorInputs: ReadonlyArray<{readonly name: string; readonly type: string}>;
  readonly abi: ReadonlyArray<{readonly name: string; readonly inputs: ReadonlyArray<{readonly name: string; readonly type: string}>}>;
  readonly bytecodeHex: string;
  readonly asm: string;
}
export interface GardenStateBytes { open: boolean; completed: number; units: number; record: Uint8Array }
export interface NftToken { amount: bigint; category: Uint8Array; nft: {capability: 'none' | 'mutable' | 'minting'; commitment: Uint8Array} }
type PublicKey = string | Uint8Array;

export declare const FOCUS_GARDEN_ARTIFACT: FocusGardenArtifact;
export declare const BATON_SATOSHIS: bigint;
export declare const TREE_SATOSHIS: bigint;
export declare const FUNCTION_INDEX: Readonly<{open: 0; complete: 1; abandon: 2}>;
export declare const UNIT_SECONDS: 512;
export declare const BIP68_TIME_FLAG: number;
export declare const BIP68_DISABLE_FLAG: number;
export declare const MIN_UNITS: 1;
export declare const MAX_UNITS: 1024;
export declare const STATE_BYTES: 40;
export declare const TREE_BYTES: 39;
export declare const GENESIS_STATE: Uint8Array;

export declare function parseCategory(category: string): string;
export declare function focusGardenRedeemBytecode(options: {ownerPublicKey: PublicKey; category: string}): Uint8Array;
export declare function focusGardenLockingBytecode(options: {ownerPublicKey: PublicKey; category: string}): Uint8Array;
export declare function focusGardenAddress(options: {ownerPublicKey: PublicKey; category: string; prefix: string}): string;
export declare function encodeFocusGardenUnlocking(options: {fn: 'open' | 'complete' | 'abandon'; signature: Uint8Array; units?: number; record?: Uint8Array; redeemBytecode: Uint8Array}): Uint8Array;
export declare function batonToken(category: string, commitment: Uint8Array): NftToken;
export declare function treeToken(category: string, commitment: Uint8Array): NftToken;
export declare function readBatonOutput(output: {lockingBytecode: Uint8Array; token?: unknown}, category: string, covenantLocking: Uint8Array): GardenStateBytes | undefined;
export declare function verifyCanonicalGenesis(options: {transaction: {inputs: ReadonlyArray<{outpointTransactionHash: Uint8Array; outpointIndex: number}>; outputs: ReadonlyArray<{lockingBytecode: Uint8Array; token?: unknown}>}; category: string; covenantLocking: Uint8Array}): true;

export declare function unitsForDurationSeconds(seconds: number): number;
export declare function minimumWaitSeconds(units: number): number;
export declare function relativeLockSequence(units: number): number;
export declare function encodeGardenState(state: {open: boolean; completed: number; units?: number; record?: Uint8Array}): Uint8Array;
export declare function decodeGardenState(bytes: Uint8Array): GardenStateBytes;
export declare function encodeTreeCommitment(tree: {index: number; units: number; record: Uint8Array}): Uint8Array;
export declare function decodeTreeCommitment(bytes: Uint8Array): {index: number; units: number; minimumWaitSeconds: number; record: Uint8Array};
