import type {WalletOptions, WalletSession} from './core.js';
import type {ConnectedWalletOptions, ConnectedSession} from './connected.js';
export {CONNECTED_PATH} from './connected.js';
export type {ConnectedWalletOptions, ConnectedSession, ConnectedSignRequest, ConnectedPathXpub, ConnectedPaymentReview} from './connected.js';
export {NETWORKS, formatBch, parseBch, validateRecipient, validateTokenRecipient, BroadcastUncertainError, WalletOperationError} from './core.js';
export type {
  Network, WalletOptions, WalletSession, PaymentReview, ElectrumTransport, TransactionKind, PendingRecord,
  PendingStatus, BroadcastOptions, BroadcastResult, FocusGardenReview, JournalChunkReview, Garden, GardenState,
  FocusGardenApi, JournalApi,
  TransactionProposal, TransactionReview, SignedTransactionExport,
  MessageReview, MessageSignature,
  NftSelection, TokenInventory, TokenPaymentReview, TokenConsensusPolicy,
} from './core.js';
export declare function createWallet(options: WalletOptions): Promise<WalletSession>;
export declare function connectWallet(options: ConnectedWalletOptions): Promise<ConnectedSession>;
