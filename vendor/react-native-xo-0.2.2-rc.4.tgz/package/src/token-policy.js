import { binsAreEqual, hash256, hashTransaction, hexToBin } from '@bitauth/libauth';
import { z } from 'zod';
import { NETWORKS } from './networks.js';
import { WalletOperationError } from './errors.js';

export const TOKEN_POLICY_ID = 'chipnet-preview2027-final-p2pkh-v1';
export const TOKEN_POLICY_COMMIT = '3e6827e95c7a17497e09ac15556debd116dea1d0';
export const tokenPolicySelection = z.literal(TOKEN_POLICY_ID);
const anchors = Object.freeze([
  Object.freeze({height: NETWORKS.chipnet.checkpointHeight, hash: NETWORKS.chipnet.checkpointHash}),
  Object.freeze({height: 284827, hash: '000000007af65a6e8853f858b3f2a8e7edabe41e6264410276705b324267d7d8'}),
]);
const hash = z.string().regex(/^[0-9a-f]{64}$/);
const header = z.string().regex(/^[0-9a-fA-F]{160}$/);
export const tokenPolicyEvidence = z.object({
  id: tokenPolicySelection, network: z.literal('chipnet'), sourceCommit: z.literal(TOKEN_POLICY_COMMIT),
  vm: z.literal('BCH_2026_05-final-p2pkh-subset'), trust: z.literal('electrum-not-spv'),
  anchors: z.tuple(anchors.map(a => z.object({height:z.literal(a.height),hash:z.literal(a.hash)}).strict())),
  tipHeight: z.number().int().min(284827), tipHash: hash,
  medianTimePast: z.number().int().min(1794744000).max(1826279999), maximumCommitmentBytes:z.literal(128),
}).strict();
export function freezeTokenPolicy(value) {
  const parsed = tokenPolicyEvidence.parse(value);
  return Object.freeze({...parsed, anchors:Object.freeze(parsed.anchors.map(a=>Object.freeze(a)))});
}

// Fixed source contract, not generic VM2027 or caller-supplied activation proof.
export async function resolveTokenPolicy(selection, network, client) {
  if (selection === undefined) return null;
  const id=tokenPolicySelection.parse(selection);
  if (network!=='chipnet') throw new WalletOperationError('consensus-policy-network','The explicit preview policy is Chipnet-only.');
  for (const anchor of anchors) {
    const raw=header.parse(await client.request('blockchain.block.header',[anchor.height]));
    if(hashTransaction(hexToBin(raw))!==anchor.hash) throw new WalletOperationError('consensus-policy-source','Source checkpoint disagrees with the pinned chain.');
  }
  const tip=z.object({height:z.number().int().min(10),hex:header}).passthrough().parse(await client.request('blockchain.headers.subscribe',[]));
  const range=z.object({count:z.literal(11),hex:z.string().regex(/^[a-fA-F0-9]{1760}$/)}).passthrough().parse(await client.request('blockchain.block.headers',[tip.height-10,11]));
  const headers=Array.from({length:11},(_,i)=>hexToBin(range.hex.slice(i*160,(i+1)*160)));
  for(let i=1;i<11;i++) if(!binsAreEqual(headers[i].slice(4,36),hash256(headers[i-1]))) throw new WalletOperationError('consensus-policy-source','Unlinked source headers.');
  if(!binsAreEqual(headers[10],hexToBin(tip.hex))) throw new WalletOperationError('consensus-policy-source','Source tip/range mismatch.');
  const times=headers.map(h=>new DataView(h.buffer,h.byteOffset,h.byteLength).getUint32(68,true)).sort((a,b)=>a-b);
  if(tip.height<284827 || times[5]<1794744000) throw new WalletOperationError('consensus-policy-inactive','The explicit preview epoch is inactive.');
  if(times[5]>=1826280000) throw new WalletOperationError('consensus-policy-unknown','Unknown future epoch; no supported preview subset authorization.');
  return freezeTokenPolicy({id,network,sourceCommit:TOKEN_POLICY_COMMIT,vm:'BCH_2026_05-final-p2pkh-subset',trust:'electrum-not-spv',anchors,tipHeight:tip.height,tipHash:hashTransaction(hexToBin(tip.hex)),medianTimePast:times[5],maximumCommitmentBytes:128});
}
export function assertTokenPolicyContinuation(approved,current) {
  if(JSON.stringify(approved)!==JSON.stringify(current)) throw new WalletOperationError('consensus-policy-changed','Approved source/tip/policy changed; retain saved raw and reconcile without retrying.');
}
export function assertTokenPolicyContext(transaction, inputs, owner, byteLength) {
  if(owner.length!==25 || owner[0]!==0x76 || owner[1]!==0xa9 || owner[2]!==0x14 || owner[23]!==0x88 || owner[24]!==0xac || transaction.version!==2 || transaction.locktime!==0 || inputs.length<1 || inputs.length>40 || transaction.inputs.length!==inputs.length || transaction.outputs.length>3 || byteLength>10000 || inputs.some((input,i)=>input.script!=='owner' || input.utxo.coinbase || !binsAreEqual(input.utxo.output.lockingBytecode,owner) || transaction.inputs[i].sequenceNumber!==0xffffffff || transaction.inputs[i].outpointTransactionHash.every(byte=>byte===0))) throw new WalletOperationError('consensus-policy-context','Preview subset requires final noncoinbase inputs from ONE selected P2PKH authority.');
}
