import { initializeLibauth } from 'react-native-libauth';
import { createWalletSession } from './core.js';
import { createConnectedSession } from './connected.js';
export { CONNECTED_PATH } from './connected.js';
export { NETWORKS, formatBch, parseBch, validateRecipient, validateTokenRecipient, BroadcastUncertainError, WalletOperationError } from './core.js';

/** Await native crypto before any XO key or signing operation. */
export async function createWallet(options) {
  await initializeLibauth();
  return createWalletSession(options);
}

/**
 * Watch and spend a wallet whose keys stay in another app (for example one
 * connected over WizardConnect). The signer signs; this session never holds keys.
 */
export async function connectWallet(options) {
  await initializeLibauth();
  return createConnectedSession(options);
}
