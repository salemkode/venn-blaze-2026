// Encrypted journal publication format (BCH data carrier, OP_RETURN).
//
// The package publishes OPAQUE bytes the application already encrypted with an
// authenticated cipher. It never receives keys or plaintext and cannot verify
// that the bytes are ciphertext; the host must only pass AEAD output.
//
// One output per transaction:
//   OP_RETURN <"XOFJ"> <header: version | index | count | id[16]> <chunk>
// `id` is the first 16 bytes of SHA-256(ciphertext), so a reader can confirm a
// reassembled publication is complete and unmodified. Standard relay allows at
// most 223 data-carrier bytes per transaction (libauth counts script length + 1).
import { binToHex, binsAreEqual, decodeAuthenticationInstructions, encodeDataPush, flattenBinArray, hexToBin, sha256, utf8ToBin } from '@bitauth/libauth';

export const JOURNAL_PROTOCOL = 'XOFJ';
export const JOURNAL_VERSION = 1;
export const JOURNAL_CHUNK_BYTES = 192;
export const JOURNAL_MAX_CHUNKS = 8;
export const JOURNAL_MIN_BYTES = 40; // e.g. XChaCha20-Poly1305: 24-byte nonce + 16-byte tag
export const JOURNAL_MAX_BYTES = JOURNAL_CHUNK_BYTES * JOURNAL_MAX_CHUNKS;
export const MAX_DATA_CARRIER_BYTES = 223;
const tag = utf8ToBin(JOURNAL_PROTOCOL);

function ciphertextBytes(ciphertext) {
  const bytes = typeof ciphertext === 'string' && /^(?:[0-9a-fA-F]{2})+$/.test(ciphertext) ? hexToBin(ciphertext) : ciphertext;
  if (!(bytes instanceof Uint8Array)) throw new TypeError('Ciphertext must be hex or bytes.');
  if (bytes.length < JOURNAL_MIN_BYTES || bytes.length > JOURNAL_MAX_BYTES) throw new RangeError(`Encrypted record must be ${JOURNAL_MIN_BYTES}..${JOURNAL_MAX_BYTES} bytes (at most ${JOURNAL_MAX_CHUNKS} transactions).`);
  return bytes;
}

/** Deterministic, network-free publication plan. */
export function planJournalPublication(ciphertext) {
  const bytes = ciphertextBytes(ciphertext);
  const id = sha256.hash(bytes).slice(0, 16);
  const chunks = [];
  for (let offset = 0; offset < bytes.length; offset += JOURNAL_CHUNK_BYTES) chunks.push(bytes.slice(offset, offset + JOURNAL_CHUNK_BYTES));
  return { id: binToHex(id), chunks, totalBytes: bytes.length };
}

export function encodeJournalOutput({ id, index, count, chunk }) {
  if (!Number.isInteger(count) || count < 1 || count > JOURNAL_MAX_CHUNKS || !Number.isInteger(index) || index < 0 || index >= count) throw new RangeError('Invalid journal chunk index.');
  if (!(chunk instanceof Uint8Array) || chunk.length < 1 || chunk.length > JOURNAL_CHUNK_BYTES) throw new RangeError('Invalid journal chunk.');
  const header = flattenBinArray([Uint8Array.of(JOURNAL_VERSION, index, count), hexToBin(id)]);
  if (header.length !== 19) throw new TypeError('Journal id must be 16 bytes.');
  const lockingBytecode = flattenBinArray([Uint8Array.of(0x6a), encodeDataPush(tag), encodeDataPush(header), encodeDataPush(chunk)]);
  if (lockingBytecode.length + 1 > MAX_DATA_CARRIER_BYTES) throw new RangeError('Journal output exceeds the standard data-carrier limit.');
  return { lockingBytecode, valueSatoshis: 0n };
}

/** Parse one output; undefined when it is not an XOFJ v1 output. */
export function decodeJournalOutput(lockingBytecode) {
  if (!(lockingBytecode instanceof Uint8Array) || lockingBytecode[0] !== 0x6a) return undefined;
  const instructions = decodeAuthenticationInstructions(lockingBytecode.slice(1));
  if (instructions.length !== 3 || instructions.some(item => 'malformed' in item || !(item.data instanceof Uint8Array))) return undefined;
  const [protocol, header, chunk] = instructions.map(item => item.data);
  if (!binsAreEqual(protocol, tag) || header.length !== 19 || header[0] !== JOURNAL_VERSION) return undefined;
  const [, index, count] = header;
  if (count < 1 || count > JOURNAL_MAX_CHUNKS || index >= count || chunk.length < 1 || chunk.length > JOURNAL_CHUNK_BYTES) return undefined;
  return { id: binToHex(header.slice(3)), index, count, chunk };
}

/** Reassemble ordered chunks and verify the content id. Throws if incomplete or altered. */
export function assembleJournal(parts) {
  if (!parts.length) throw new Error('No journal chunks.');
  const [{ id, count }] = parts;
  if (parts.length !== count || parts.some((part, index) => part.id !== id || part.count !== count || part.index !== index)) throw new Error('Journal chunks are missing, duplicated, or out of order.');
  const bytes = flattenBinArray(parts.map(part => part.chunk));
  if (binToHex(sha256.hash(bytes).slice(0, 16)) !== id) throw new Error('Journal content does not match its id.');
  if (parts.slice(0, -1).some(part => part.chunk.length !== JOURNAL_CHUNK_BYTES)) throw new Error('Journal chunk sizes are not canonical.');
  return { id, ciphertext: bytes };
}
