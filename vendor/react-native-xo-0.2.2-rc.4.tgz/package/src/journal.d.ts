export declare const JOURNAL_PROTOCOL: 'XOFJ';
export declare const JOURNAL_VERSION: 1;
export declare const JOURNAL_CHUNK_BYTES: 192;
export declare const JOURNAL_MAX_CHUNKS: 8;
export declare const JOURNAL_MIN_BYTES: 40;
export declare const JOURNAL_MAX_BYTES: number;
export declare const MAX_DATA_CARRIER_BYTES: 223;
export interface JournalChunk { id: string; index: number; count: number; chunk: Uint8Array }
export declare function planJournalPublication(ciphertext: string | Uint8Array): {id: string; chunks: Uint8Array[]; totalBytes: number};
export declare function encodeJournalOutput(chunk: JournalChunk): {lockingBytecode: Uint8Array; valueSatoshis: bigint};
export declare function decodeJournalOutput(lockingBytecode: Uint8Array): JournalChunk | undefined;
export declare function assembleJournal(parts: JournalChunk[]): {id: string; ciphertext: Uint8Array};
