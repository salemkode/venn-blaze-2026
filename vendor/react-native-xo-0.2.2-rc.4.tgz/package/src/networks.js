import { z } from 'zod';

export const networkName = z.enum(['chipnet', 'mainnet']);
export const NETWORKS = Object.freeze({
  chipnet: Object.freeze({
    label: 'Chipnet', prefix: 'bchtest', coinType: 1,
    endpoint: 'wss://chipnet.imaginary.cash:50004',
    // Official Chipnet split anchor, distinct from testnet4 at this height.
    // BCHN v29.2.0 src/chainparams.cpp, CChipNetParams (not CTestNet4Params).
    checkpointHeight: 115252,
    checkpointHash: '00000000040ba9641ba98a37b2e5ceead38e4e2930ac8f145c8094f94c708727',
    checkpointSource: 'https://github.com/bitcoin-cash-node/bitcoin-cash-node/blob/v29.2.0/src/chainparams.cpp',
    explorer: 'https://chipnet.chaingraph.cash/tx/',
  }),
  mainnet: Object.freeze({
    label: 'Mainnet', prefix: 'bitcoincash', coinType: 145,
    endpoint: 'wss://electrum.imaginary.cash:50004',
    checkpointHeight: 478559,
    checkpointHash: '000000000000000000651ef99cb9fcbe0dadde1d424bd9f15ff20136191a5eec',
    explorer: 'https://blockchair.com/bitcoin-cash/transaction/',
  }),
});
