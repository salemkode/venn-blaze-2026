##0.2.2-rc.4 (local candidate)

- Add `connectWallet()` / `react-native-xo/connected`: a session for a wallet
  whose keys stay in another app (WizardConnect hdwalletv1). It derives
  receive/change addresses from the shared branch xpubs with a gap-limit scan,
  verifies every output against its hash-checked source transaction, builds BCH
  payments, asks the signer to sign without broadcasting, refuses signed bytes
  that differ from the built payment or fail both BCH VMs, and broadcasts only
  after `persistPending`. Pending records use path `connected`.
- No change to `createWallet`, rc.3 token policy, journal or native ABI.

##0.2.2-rc.3 (local candidate)

- Add explicit source-backed chipnet-preview2027-final-p2pkh-v1 token policy for
  selected NFT commitments up to128bytes, authoritative BCH2026 standard VM,
  exact source/epoch/tip/authority checks and immutable reviewed/journal policy.
- Preserve omitted-default rc2 metadata/40bytes/both VMs. Retain original pending
  after durable-write policy race failure, consume approval without submission.
- No native ABI change or generic VM2027/covenant/coinbase/mixed-address support.

##0.2.2-rc.2 (local candidate)

- Add a second immutable signed-transaction argument to the existing approval-
  boundary persistPending callback, awaited before submission/export. Existing
  one-argument callbacks remain compatible. No prepare/review raw exposure or
  broadening of token/payment export. Host owns durable commit/fsync.

# Changelog

## 0.2.2-rc.1 — local Chipnet consumer candidate

- Add reviewed compact Bitcoin Signed Message ECDSA/Base64 export with exact
  UTF-8/peer/address/network binding, cancellation/expiry and single export.
- Add independently source-verified token inventory, token-aware receiving and
  bounded FT/one-selected-NFT payments: exact base units, all-output review,
  no mint/burn/mutation, dynamic dust and 0x61 signatures, both BCH VMs.
- Retain 40-byte NFT commitment intersection of both pinned VMs; explicitly
  flag/refuse 2026-only larger commitments without truncation or fake support.
- Bind new pending records to the wallet address and recognize token-payment;
  legacy path-only records remain accepted with host identity namespacing.
- Pin Chipnet identity to official BCHN29.2.0 split checkpoint115252, preserving
  legacy121957 observations and all0.2.0/0.2.1 delivered artifact bytes.
- Add portable offline wallet QA runnable by host tests and the native example.
  Actual native/funded Chipnet journeys still require separate evidence.

## 0.2.1 — unreleased local extension

- Add `exportXpub({scope, acknowledgePrivacy: true})` for public BIP44 account
  or receive/change/DeFi branch nodes. Encode network-correct Base58Check xpub
  or tpub; never export private/master keys or automatically send to peers.
- Permit explicit branch 7 selection/public child derivation without changing
  original defaults or the single-address spending boundary.
- Add optional proposal `signingType: 'SIGHASH_ALL|FORKID|UTXOS'` (0x61), using
  upstream Libauth source-output commitments and both BCH standard VMs. Default
  and explicit legacy 0x41 remain supported. Unsupported modes fail closed.
- Keep all existing approval/export/pending, network, fee and ownership checks.
  Token, covenant and foreign-input signing remain unsupported; these primitives
  alone do not implement WizardConnect, HD discovery or generic DeFi support.
- Preserve the tested 0.2.0 artifact and its manifests unchanged; deliver a new
  local artifact and separate evidence for this version. No publication.

## 0.2.0 — unreleased local development

- Retain FocusGarden covenant and bounded opaque journal APIs from the existing
  branch, including their VM verification and pending safeguards.
- Accept standard BCH P2SH32 recipients with script-specific dust checking.
- Add optional BIP44 account/change/index session selection and public
  `deriveAddress`; default derivation is unchanged. No automatic discovery.
- Add version 1 `prepareTransaction` for reviewed BCH-only, fully wallet-owned
  proposals; full-commitment BCH Schnorr signatures and BCH 2025/2026 VM checks.
- Add `exportSignedTransaction`: requires pending persistence, re-checks inputs,
  consumes the review and reserves inputs before releasing signed bytes. No
  implicit broadcast, partial signing, arbitrary contract spending or protocol
  session support.
- Add optional `path` to pending records; accept legacy records at the original
  default address and reject mismatching HD paths. Recognize kind `transaction`.

Local artifacts are identified by SHA-256 in the repository's WORK-STATUS.md;
this version has not been published. Native adapter remains 0.2.1; exact XO
peer Libauth version remains 3.1.0-next.8.
