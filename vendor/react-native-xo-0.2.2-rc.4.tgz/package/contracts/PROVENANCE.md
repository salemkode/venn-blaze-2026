# FocusGarden contract provenance

`FocusGarden.cash` and `FocusGarden.artifact.json` are byte-identical copies of
the Focus Garden app's `contracts/focus/` files (branch `feat/focus-garden-native`,
copied 2026-11-14). The app compiled the artifact with exact `cashc` 0.14.0
(`enforceFunctionParameterTypes`, `enforceLocktimeGuard`) and checks it against
the source. This package does not depend on `cashc` and never imports app files.

| File | SHA-256 |
| --- | --- |
| `FocusGarden.cash` | `ac26fdd97cf34996a4154b56ee72ccbd85f4ee4b49bc3af6ee8e88dd4382910e` |
| `FocusGarden.artifact.json` | `864a88c138eeaa16d1a5ae3d53b279804b65978d76ad402f0ae1b71d320937e7` |
| App `protocol.js` (layout mirrored in `src/focus-garden/protocol.js`) | `1b1ed3bd44761f1d7b068ae6b165f9a6043e16be750e8d9887f907dc9d43242a` |

`src/focus-garden/artifact.js` embeds the artifact's ABI, constructor inputs,
compiled bytecode and ASM so React Native bundles need no JSON import.
`tests/xo-focus-garden.test.mjs` verifies, on every run:

- both file hashes above and that `artifact.source` equals `FocusGarden.cash`;
- the embedded bytecode, ASM, ABI and constructor inputs equal the JSON;
- libauth's independent disassembly of the bytecode equals cashc's ASM;
- package sources only import relative package files, libauth, XO primitives or zod.

To update the contract: recompile in the owning project with the pinned
compiler, copy both files here, regenerate `artifact.js` from the JSON, update
this table, and treat it as a new contract version. Existing gardens remain
bound to the bytecode they were created with; a changed bytecode yields a
different covenant address.
