# react-native-xo

A small **BCH send/receive wallet core** built with real `@xo-cash/primitives`
and `@bitauth/libauth`. Native crypto comes from the separate
`react-native-libauth` adapter. The [wallet template](https://github.com/salemkode/xo-react-native-wallet)
is a consuming app, not a required framework.

This package uses XO's modular **primitives layer**, not `@xo-cash/engine`.
It does not implement XO invitations, XO contract templates, or CashConnect.
Its candidate token handling is bounded FT payment and one selected NFT transfer,
plus the FocusGarden covenant below. It does not provide arbitrary token/covenant
proposal signing. The engine's Node/browser storage
dependencies are not made React Native compatible by installing this package.

## Install in another React Native app

The packages are distributed as public GitHub release tarballs, not npm registry
releases. Use React Native 0.81.5, React 19.1, New Architecture, and Hermes:

```sh
npm install \
  https://github.com/salemkode/react-native-libauth/releases/download/v0.2.1/react-native-libauth-0.2.1.tgz \
  https://github.com/salemkode/react-native-libauth/releases/download/v0.2.0/react-native-xo-0.1.0.tgz \
  @bitauth/libauth@3.1.0-next.8 @callstack/polygen@0.2.1 \
  react-native-get-random-values@1.11.0
npx libauth-native --setup
npx libauth-native
# iOS: cd ios && pod install
```

Append `libauth-native --js-only` to your existing `postinstall`. Generate native
sources after reinstalling dependencies, then rebuild your app. Expo Go cannot
load native crypto; use a custom development build or a bare app.

```js
import {createWallet} from 'react-native-xo';

export async function openWallet(mnemonicFromSecureStorage) {
  const wallet = await createWallet({
    mnemonic: mnemonicFromSecureStorage,
    network: 'chipnet', // safe default; 'mainnet' uses real BCH
  });
  console.log(wallet.address); // public; never log the mnemonic
  const balance = await wallet.refresh();
  return {wallet, balance};
}
```

For sending, call `wallet.prepareSend({address, amountBch: '0.0001'})`, display
its address, amount, fee, total, and network, then call `wallet.broadcast(review.id)`
only after the user confirms. `cancelSend()` invalidates the review. A review
expires after two minutes. `close()` destroys the session key and closes its socket.

**Persist the review's pending record before broadcasting.** Pass
`{persistPending}` to `broadcast` (required for garden and journal actions); it is
awaited after the inputs are re-checked and before submission, and a throw aborts
with nothing sent. A timeout may mean the transaction was accepted. Never
automatically retry. See [Pending transactions and restart](#pending-transactions-and-restart).
Keep the seed in Keychain/Keystore, never AsyncStorage.

The development candidate (0.2.2-rc.1) is not released. For local integration build a
tarball from this repository: `npm pack --workspace packages/react-native-xo
--pack-destination /path/to/app/vendor`, then install that file.

## Behavior and limits

- Chipnet and Mainnet use separate default BIP44 paths: `m/44'/1'/0'/0/0` and
  `m/44'/145'/0'/0/0`. Optional `hd: {account, change, index}` selects one address
  per session; `deriveAddress({change, index})` derives public children of the
  selected account, without scanning or spending them. BIP39 English
  recovery phrases; no additional BIP39 passphrase. This is **not XO Engine's
  invitation derivation scheme** and does not restore an XO Engine account.
- Strict prefixed CashAddress recipients, standard P2PKH/P2SH20/P2SH32, minimum
  546 sats and each script's dust threshold (576 sats for P2SH32).
- Integer amounts validated by XO `Satoshis`; never floating-point BCH arithmetic.
- Real XO `PrivateKey` and `TransactionHash` validation; native BCH Schnorr signing.
- Verifies a known BCH/Chipnet fork block to detect wrong-network endpoints.
  Fetches and hashes source transactions, checks amounts/scripts, and validates
  every signed transaction in libauth's VM before submission.
- Fixed conservative 1 sat/byte fee estimate, disclosed dust remainder, up to 100
  inputs / 200 listed outputs. Token-bearing and coinbase outputs are never funding.
- Uses encrypted Electrum WebSockets. Server availability and reported unspent
  status are trusted; this package is **not a complete SPV client**.
- Successful submissions remain blocked in-session until refresh observes their
  inputs spent. Unknown submissions require application-level reconciliation.
- No automatic broadcast retries, arbitrary token sends, address discovery, or full
  wallet history. No independent security audit; begin on Chipnet.

## Reviewed transaction proposals (local 0.2.1)

The existing `prepareSend({address, amountBch})` accepts P2SH32 invoice addresses.
The host must first verify the invoice's terms, rederived address, amount, network
and expiry; address validation alone does not establish invoice authenticity.

For an already constructed BCH transaction, `prepareTransaction` accepts exactly
`{version: 1, network, unsignedTransaction: hex, maxFeeSatoshis: string}` with
optional `signingType: 'SIGHASH_ALL|FORKID|UTXOS'` (0x61). Omitting it preserves
the original `SIGHASH_ALL|FORKID` (0x41); unknown modes are refused. All
inputs must be unspent BCH-only outputs of the selected session address, with
empty unlocking scripts and final sequences. Version 2/locktime zero and standard
P2PKH/P2SH20/P2SH32 outputs are supported; token, OP_RETURN, foreign, multisig and
covenant inputs are refused. No fields or change are added. The proposal is signed
with the selected BCH Schnorr signing type and verified in both BCH 2025/2026
VMs. UTXOS mode commits to every independently fetched source output and is
required by WizardConnect; never downgrade it in the protocol adapter.
The fee must be positive, at most the cap (itself <= 100000 sats), and 1–100 sat/B.

The immutable review lists all outputs, exact amounts, network, fee, txid and
expiry. After human approval call
`exportSignedTransaction(review.id, {persistPending})` to obtain
`{kind: 'transaction', network, txid, signedTransaction: hex, pending}` without
broadcasting. Export rechecks inputs, awaits durable persistence and blocks new
spending before releasing the bytes. Alternatively use the existing explicit
`broadcast(review.id, {persistPending})` once. Never automatically retry an export
or ambiguous broadcast. The new `transaction` kind and optional `path` are part
of the pending record; legacy pathless records restore only at the original
default derivation. Namespace stored pending records by wallet identity and HD
selection. HD selection does not implement address discovery or aggregation.

These primitives do not implement WalletConnect sessions or arbitrary contract
signing. Exact review fields, error codes, recovery behavior and OX integration
instructions are in [the integration contract](../../docs/wallet-contract-api.md).
Local tarball/checksum handoff is in the repository's `WORK-STATUS.md`.

## Candidate 0.2.2-rc.1: message approval and token payments

`prepareMessage({peer, message})` reviews the exact text, selected address and
peer. After human approval, `exportMessageSignature(id, {peer})` returns standard
Bitcoin Signed Message recoverable ECDSA in Base64 (65 bytes, compressed header
31–34). It is not Schnorr or raw-hash signing. Empty text is supported; maximum
4096 UTF-8 bytes, no normalization/trimming, malformed Unicode and unsafe control
characters refused. Reviews share the existing cancellation/expiry slot, are
consumed once, and release no signature before export. The host binds the peer
to the approved session and owns nonce/domain/expiry/replay policy. The message
does not prove issuer authority, token entitlement or course ownership.

For receiving use `wallet.tokenAddress`. `refreshTokens()` returns source-verified
exact category totals and NFT outpoints/capabilities/commitments for the selected
address. No metadata/decimals or issuer authority are inferred.

```js
const review = await wallet.prepareTokenSend({
  address: approvedTokenAwareRecipient,
  category: exactLowercaseCategoryTxid,
  amount: exactBaseUnitsString,
  // Optional single NFT; use ONLY these four source snapshot fields:
  nft: {txid, index, capability, commitment},
});
// Show category, base units, NFT snapshot, every output, dust backing and fee.
// After human approval, and durable encrypted pending persistence:
await wallet.broadcast(review.id, {persistPending});
```

Recipients must be matching-network token-aware P2PKH/P2SH20/P2SH32 addresses.
Amount is canonical integer base units 0..9223372036854775807; zero requires an
NFT. Category/commitment use lowercase display-order hex. No float conversion.
Select only fungible-only outputs of that category plus the exact selected NFT;
all FT remainder and NFT capability/commitment are preserved. Unrelated NFTs,
categories and coinbase outputs are never funding. Additional BCH is BCH-only.
The builder computes token-prefix dust and 1 sat/byte signatures, bounds fees,
enforces conservation independently and verifies both BCH 2025/2026 standard
VMs with ALL|FORKID|UTXOS signatures. No mint, burn, mutation, contract inputs
or generic token proposal signing. Mainnet token payment requires the existing
explicit contracts opt-in; Chipnet is the test-delivery network.

NFT commitments are limited to **40 bytes**, the common supported set of both
pinned VMs. 2026-specific 41–128-byte commitments are visible in inventory with
`commitmentSupported:false` but refused for this transfer API; no truncation.
Inventory support is not a promise of adequate funds, confirmation or authority.

The immutable `token-payment` review provides category/amount/NFT, exact FT
input/change/zero burn, all outputs and roles, recipient BCH backing, BCH debit,
fee and existing base/pending fields. Submission requires persistence; unknown
outcomes remain blocked across restart and are never retried automatically.
New pending records also bind the wallet `address`; old address-less records
remain supported but require host wallet-identity namespacing. Update strict
host record validators for the new kind/address before adopting this candidate.

The candidate now pins official BCHN29.2.0 Chipnet split block115252 instead of
the historical project pin121957. A prefix or CAIP label is not chain proof.
Precise fields, migration and testnet evidence are in `docs/candidate-apis.md`
and `RELEASE-STATUS.md` in the source repository. Earlier0.2.0/0.2.1 artifacts
remain immutable. Neither testnet functional delivery nor public release is
claimed complete without native and funded-app journey evidence.

## Explicit public extended-key export (local 0.2.1)

After human approval of the exact peer, network and public scope, call
`wallet.exportXpub({scope: 'receive', acknowledgePrivacy: true})`. Scopes are
`account`, `receive`, `change` and `defi`; the frozen result is
`{scope, network, path, xpub}`. Account means the selected BIP44 account at depth
3; receive/change/defi mean branches 0/1/7 at depth 4. Mainnet uses standard
Base58Check xpub and Chipnet uses tpub. No private or master key is exported.
`hd.change` and `deriveAddress.change` now also accept 7 to select/recover an
individual DeFi-branch address. Defaults remain unchanged.

An extended public key reveals past/future addresses; disconnecting cannot
revoke that knowledge. An xpub plus a leaked non-hardened child private key can
compromise ancestor keys. The acknowledgment flag is an explicit caller guard,
not an implementation of human approval. Share only approved branch scopes,
never an account scope by convenience, and never log or expose private keys.

For hdwalletv1 send only approved `{name: 'receive'|'change'|'defi', xpub}`
entries. Do not send account scope or internal paths. Force proposal signingType
to `SIGHASH_ALL|FORKID|UTXOS`, verify review.signingType and then use the existing
approved export/pending path. The session still signs one selected address;
all input paths must match it. Multi-address signing, automatic discovery and
gap-limit recovery are not implemented. Persist branch/index metadata and do
not advertise generic DeFi or a complete connection protocol from these library
primitives. Exact mapping and remaining app obligations are documented in
`docs/wizardconnect-capabilities.md` in the source repository.

## One review at a time

Payments, transaction proposals, garden actions and journal chunks share **one** draft slot and one
operation latch. Preparing anything replaces the previous review; a second
operation while one runs fails with `WalletOperationError` code `busy`; nothing
can be prepared while a broadcast is pending (`pending`). `cancelSend()` (alias
`focusGarden.cancel()` / `journal.cancel()`) cancels the shared review, including
one still being prepared. Reviews expire after two minutes and broadcast once.
Each family broadcasts through its own method (`broadcast`, `focusGarden.broadcast`,
`journal.broadcast`); using the wrong one fails with `wrong-kind`.

Before submission every broadcast re-reads the wallet's BCH outputs and, for
garden actions, the covenant baton. If any funding or covenant input changed,
it fails with `input-spent` and nothing is persisted or sent.

## FocusGarden covenant

`wallet.publicKey` is the compressed owner key (hex), used as the covenant's
`owner`. It is public; the private key never leaves the session. The covenant
is the pinned `contracts/FocusGarden.cash` artifact (cashc 0.14.0, see
`contracts/PROVENANCE.md`). Constructor arguments are compiled exactly as
CashScript does (`gardenCategory` in wire order, then `owner`, then the bytecode)
and locked with P2SH32. Categories are passed as txid-order hex.

```js
const persistPending = record => secureStore.save('pending', record); // encrypted, awaited
const genesis = await wallet.focusGarden.prepareGenesis();
// show genesis.network, covenantAddress, gardenCategory, feeBch; persist gardenCategory
await wallet.focusGarden.broadcast(genesis.id, {persistPending});
const garden = await wallet.focusGarden.readGarden(category); // null if no baton yet
const open = await wallet.focusGarden.prepareOpen({category, units, record}); // record: 32-byte hex commitment
const done = await wallet.focusGarden.prepareComplete({category}); // only when garden.claimable
```

| Action | Inputs → outputs | Measured size/fee (1 sat/B) |
| --- | --- | --- |
| `prepareGenesis()` | owner output **at index 0** (+ BCH) → minting baton (1000 sats, `GENESIS_STATE`) at the covenant, BCH change | 304 B |
| `prepareOpen({category, units, record})` | baton, BCH → baton (open) [, BCH change] | 924 B |
| `prepareComplete({category})` | baton with sequence `0x400000 \| units` (version 2), BCH → baton (idle, count+1), one immutable tree (1000 sats) to the owner [, BCH change] | 998 B + 1000-sat tree |
| `prepareAbandon({category})` | baton, BCH → baton (idle) [, BCH change] | 890 B |

- Every input is signed with the session key (BCH Schnorr, `SIGHASH_ALL|FORKID`)
  and the whole transaction is verified in libauth's **BCH 2025 and BCH 2026
  standard VMs** before a review is returned. Token conservation, covenant rules,
  dust and data-carrier limits are part of that check.
- Fees and change use only verified BCH-only owner outputs. Trees, batons and any
  other token outputs are never funding. At most 20 funding inputs.
- `readGarden` verifies the baton's source transaction and the category's
  **canonical genesis**: the transaction spending `category:0` must create exactly
  one output of that category, a minting NFT at this owner's covenant with
  `GENESIS_STATE`. A second minting token, fungible amount, wrong commitment,
  foreign script, a second baton, or a missing genesis fails with `not-canonical`.
- The baton's `completed` count is the canonical record. Trees are transferable
  NFTs; counting trees at an address is not a record of focus sessions.
- **Early claims are refused.** `prepareComplete` requires a confirmed open
  output and `tip MTP ≥ MTP(confirmation height − 1) + units × 512` (BIP68/BIP113),
  otherwise codes `unconfirmed` / `not-yet-claimable` with `details.claimableAt`.
  Nodes enforce the same rule; headers come from the server (linked, not PoW-checked).
- `prepareGenesis` needs a BCH output at index 0 (CashTokens genesis rule). If
  there is none (`no-genesis-outpoint`), send a small payment to your own address
  first. Each genesis creates a **new** garden: persist `gardenCategory` and do not
  create another unless the user asks.
- Mainnet garden and journal transactions are refused (`mainnet-disabled`) unless
  `createWallet({..., allowMainnetContracts: true})`. Use Chipnet.

Network-free helpers are exported from `react-native-xo/focus-garden`
(state/tree encoding, `relativeLockSequence`, `focusGardenAddress`,
`verifyCanonicalGenesis`, the embedded artifact).

## Encrypted journal (bounded, opaque)

Standard relay (libauth 3.1's BCH model, matching BCHN's default
`-datacarriersize`) allows at most **223 data-carrier bytes per transaction**.
The journal therefore publishes **opaque bytes that the app already encrypted
with an authenticated cipher** (for example XChaCha20-Poly1305 output). The
package never receives keys or plaintext and cannot tell ciphertext from
plaintext; passing anything else is a host bug.

- 40–1536 bytes per publication, split into at most **8** chunks of 192 bytes, one
  `OP_RETURN "XOFJ" <version|index|count|id16> <chunk>` output per transaction
  (a full chunk measured 414 bytes, 414 sats at 1 sat/B).
- `id` is the first 16 bytes of SHA-256(ciphertext); `journal.read({txids})`
  reassembles chunks, verifies hashes, ordering and the id, and reports
  `authoredByWallet`. Decryption and authenticity remain the app's AEAD job.
- `journal.plan(ciphertext)` shows the chunk count first. Each chunk is its own
  `journal.preparePublish({ciphertext, chunkIndex})` review with fee and a
  disclosure, broadcast via `journal.broadcast(id, {persistPending})`. Its pending
  record carries `publication: {id, index, count}`.
- Resume after restart from the host's saved per-chunk txids: restore and resolve
  the pending record, then prepare the next missing index. Nothing is published
  automatically or in the background.
- Public forever: size, timing, chunk count, and that this wallet published it.
  Losing the app key makes it unreadable. Larger records stay local.

## Pending transactions and restart

Every review has `review.pending`, a JSON-safe record
`{version, network, kind, txid, category, inputs, createdAt, publication}`.
The host must store it (encrypted) through `persistPending` before submission.
After any broadcast, success or `BroadcastUncertainError`, `wallet.pending` is
set and **all** new reviews fail with code `pending` until resolved:

1. On launch, before any prepare, call `wallet.restorePending(savedRecord)`.
2. Call `wallet.checkPending()`. It never broadcasts:
   - `confirmed` / `mempool`: the server knows the txid and its inputs match.
     Resolved; mark the app state (e.g. `opening → open`).
   - `conflicted`: an input was spent by a different transaction; this one can
     never confirm. Resolved; re-read the garden.
   - `unknown`: not seen and every input still unspent. Still blocked. Check again
     later. Only after an explicit user decision call `wallet.discardPending(txid)`;
     if the old transaction was relayed, a new one reusing the same inputs fails
     instead of double-spending.
3. Delete the stored record once `resolved` is true.

`refresh()` also clears the block when every pending input is observed spent.
`lookupTransaction(txid)` remains available.

Advanced: `react-native-xo/core` exposes `createWalletSession` for initialized
runtimes and injected Electrum transports. `react-native-xo/electrum` exposes the
WebSocket RPC client. Neither entry installs native crypto automatically.


### Local0.2.2-rc.2: durable raw before submission

After explicit human approval, `broadcast(id,{persistPending})` now awaits
`persistPending(record, transaction)` after input preflight and before any
submission. The second argument is immutable
`{signedTransaction,txid,network,kind}`: exact lowercase signed hex and matching
review/pending identifiers. Existing one-argument callbacks remain valid, but
do not satisfy a host requirement to durably journal raw bytes. For that gate,
resolve only after BOTH record and exact raw/identity are durably committed by
the host. The library cannot promise AsyncStorage fsync or filesystem durability.
Callback rejection, closure, cancellation or expiry prevents RPC submission;
the busy latch rejects overlapping approvals. Reconcile any host record already
written before an abort; never automatically relay it or retry ambiguous sends.
Raw stays out of preparation/review. This does not broaden payment/token exports:
exportSignedTransaction still accepts only transaction-kind proposals. The same
callback is used by explicitly approved garden/journal/export paths, preserving
all source/VM/token protections. No implicit broadcast or new native crypto ABI.


### Local0.2.2-rc.3: explicit source-backed preview token subset

Optional selector `consensusPolicy:'chipnet-preview2027-final-p2pkh-v1'` on
refreshTokens/prepareTokenSend enables up to128byte selected NFT commitments
ONLY after SAME-client115252+284827 checkpoints, linked11-header tip/MTP proof
within [1794744000,1826280000). An immutable policy evidence object is echoed
ONLY on opt-in inventory/review/pending/frozen raw. Omission preserves exactrc2
shapes, default40bytes and both VMs. Native adapter/Libauth versions unchanged.

The preview source commit is3e6827e95c7a17497e09ac15556debd116dea1d0. Authoritative
local VM is BCH2026 standard for a SOURCE-BACKED FINAL-P2PKH SUBSET, not generic
VM2027: v2/locktime0/allsequence0xffffffff, <=40 verified noncoinbase UTXOs from
ONE selected P2PKH authority, <=3standard outputs/10000bytes. Mature coinbase,
foreign/mixed/covenant/locktime contexts are refused.2025 rejection of41..128 is
diagnostic only. Conservation/dust/fee/output/source protections remain.

Host must review/persist the exact policy with original signed raw/pending and
approval witness. Exact tip/source/epoch/context/cancel/expiry rechecks occur
before and after durable await; changes consume the approval and retain the
original policy pending reservation after persistence, without sending or
re-signing/retrying. Legacy missing policy means default40; restoration never
implicitly enables128. Across restart host must authenticate its whole journal;
library cannot detect a rewritten legacy record after original host state loss.
Trust is electrum-not-spv; no ownnode, preview-native or canonical-fork proof.
Current1byte OX assets do not require this opt-in. See repository
`docs/preview-token-policy.md` for exact fields/errors/source mapping and adoption
gates. No live adoption follows from a local source/consumer candidate.
